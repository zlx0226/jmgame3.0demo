<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT lazy_king,lazy_king_achieve FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $lazy_king = $row["lazy_king"];
    $lazy_king_achieve = $row["lazy_king_achieve"];
}

$lazy_king=1;
$_SESSION['lazy_king'] = $lazy_king;
$lazy_king_achieve=1;
$_SESSION['lazy_king_achieve'] = $lazy_king_achieve;


$sql = "update mytb set lazy_king=$lazy_king, lazy_king_achieve=$lazy_king_achieve where name1='$name1'";
$result = $con->query($sql);
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls ></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<style>
        body {
              background-image: url("classroom.jpg");
              background-size:100%;
              background-attachment: fixed;
              background-repeat: no-repeat;
            }
        </style>
<link href="css/caught.css" rel="stylesheet" type="text/css" />
<img src="teacher_angry.png" width=43%  class="picture"/>
<button type="submit" class='button_continue' onclick="c1()">  </button>
<script>

  var name1= <?php echo $_SESSION['username'];?>;
document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;z-index: 1;"> &nbsp;&nbsp;&nbsp;&nbsp;老师 </p></div><p class="words" style="font-size: 35px; color:white;z-index: -1;"> &nbsp;&nbsp;&nbsp;&nbsp;'+name1+' ，你的作业呢？</p></div> '


function hideElementsByClass(className)
 {
  var elements = document.querySelectorAll('.' + className);
  elements.forEach(function(element) {
    element.style.display = 'none';
  });
}

function c1(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;呃———这个事呢……怎么说呢，唉……就是这么个事…… </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c2()">  </button>';
   }
function c2(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
     document.body.innerHTML += '<img src="teacher_angry.png" width=43%  class="picture"/>'
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;老师 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;别捣糨糊！你的语文作业写完了没？ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c3()">  </button>';
   }
 function c3(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;呃！马上马上！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c4()">  </button>';
   }
 function c4(){
  hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="teacher_angry.png" width=43%  class="picture"/>'
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;老师 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;你的数学作业呢？ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c5()">  </button>';
 }
 function c5(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;哦！马上马上！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c6()">  </button>';
   }
 function c6(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="teacher_angry.png" width=43%  class="picture"/>'
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;老师 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;你的英语作业呢？ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c7()">  </button>';
 }
 function c7(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;啊……马上马上！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c8()">  </button>';
   }
 function c8(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="roommate_b.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;室友B </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp bro,你可真行！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c9()">  </button>';
 }
 function c9(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;解锁成就“摆烂”！（每天压力+3，生命+3） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="window.location.href=\'read_auto.php\'">  </button>';
 }


</script>

</body>
</html>