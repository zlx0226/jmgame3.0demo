<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT diligent_god, diligent_god_achieve FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $diligent_god = $row["diligent_god"];
    $diligent_god_achieve = $row["diligent_god_achieve"];
}

$diligent_god=1;
$_SESSION['diligent_god'] = $diligent_god;
$diligent_god_achieve = 1;
$_SESSION['diligent_god_achieve'] = $diligent_god_achieve;


$sql = "update mytb set diligent_god=$diligent_god, diligent_god_achieve=$diligent_god_achieve where name1='$name1'";
$result = $con->query($sql);
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls ></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<style>
        body {
              background-image: url("classroom.jpg");
              background-size:100%;
              background-attachment: fixed;
              background-repeat: no-repeat;
            }
        </style>
<link href="css/caught.css" rel="stylesheet" type="text/css" />
<div class = "word_box">
    <div class="name_box">
        <p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;室友A </p>
    </div>
    <p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;bro，一起去食堂吃饭吧！ </p>
</div> 
<img src="roommate_a.png" width=43%  class="picture"/>

<button type="submit" class='button_continue' onclick="c1()">  </button>
<script>
  var name1= <?php echo $_SESSION['username'];?>;

function hideElementsByClass(className)
 {
  var elements = document.querySelectorAll('.' + className);
  elements.forEach(function(element) {
    element.style.display = 'none';
  });
}

function c1(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;不了，不了。我要写作业！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c2()">  </button>';
   }
function c2(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
     document.body.innerHTML += '<img src="roommate_a_angry.png" width=43%  class="picture"/>'
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;室友A </p></div><p class="words" style="font-size: 45px; color:red;"> &nbsp;&nbsp;&nbsp;&nbsp;吃！饭！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c3()">  </button>';
   }
 function c3(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;不了，不了。我要写作业！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c4()">  </button>';
 }
 function c4(){
  hideElementsByClass("words");
    hideElementsByClass("picture");
     document.body.innerHTML += '<img src="student_wangguihua.png" width=43%  class="picture"/>'
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;王桂花 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;bro，一起去倒水吧！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c5()">  </button>';
 }
 function c5(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;不了，不了。我要写作业！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c6()">  </button>';
 }
 function c6(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
     document.body.innerHTML += '<img src="student_wangguihua_angry.png" width=43%  class="picture"/>'
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;王桂花 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;你怎么这样！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c7()">  </button>';
 }
 function c7(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<style>body {background-image: url("dormitory.jpg");background-size:100%;background-attachment: fixed;background-repeat: no-repeat;}</style>';
    document.body.innerHTML += '<img src="roommate_b.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;室友B </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;嘿！已经一点了，你不打算睡觉吗？ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c8()">  </button>';
 }
 function c8(){
        hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;不了，不了。我要写作业！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c9()">  </button>';
 }
 function c9(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="roommate_b_angry.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;室友B </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;还写？你都往前写多少了！！！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c10()">  </button>';
 }
 function c10(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<style>body {background-image: url("classroom.jpg");background-size:100%;background-attachment: fixed;background-repeat: no-repeat;}</style>';
    document.body.innerHTML += '<img src="student_yangguanlan.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;杨灌篮 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;一起去操场吧！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c11()">  </button>';
 }
 function c11(){
            hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;不了，不了。我要写作业！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c12()">  </button>';
 }
 function c12(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="student_yangguanlan_angry.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;杨灌篮 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;你这个卷狗！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c13()">  </button>';
 }
 function c13(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="student_juangou_happy.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;卷王 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;no,no,no！'+name1+' 已经突破了卷狗的界限，成为真正的卷王了！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c14()">  </button>';
 }
 function c14(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;解锁成就“卷王”！（每天压力-5，生命-7）（改编自历史真实事件：）） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="window.location.href=\'read_auto.php\'">  </button>';
 }


</script>

</body>
</html>