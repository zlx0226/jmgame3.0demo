<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body >
<audio id="music" src="music.m4a" loop="loop" hidden="true" controls ></audio>

<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }  
 
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<style>
 body {
      background-image: url("building_background2.jpg");
      background-size: cover;
      background-repeat: no-repeat;
    }
.lesson_box {
            position: absolute;
            top: 5%;
            left: 5%;
            width: 60%;
            height: 75%;
            border: 1px solid hsla(0, 0%, 44%, 0.282);
            background-color: #ffffff76;
            border-radius: 20px;
        }
.health_box1 {
            position: absolute;
            top: 5%;
            right: 5%;
            width: 25%;
            height: 65%;
            border: 1px solid #71717148;
            background-color: #ffffff76;
            border-radius: 20px;
        }
.health_box {
            position: absolute;
            top: 5%;
            right: 5%;
            width: 25%;
            height: 65%;
            border: 1px solid #71717148;
            border-radius: 20px;
        }
.health_box2 {
            position: absolute;
            top: 5%;
            right: 5%;
            width: 25%;
            height: 65%;
            border: 1px ;
            border-radius: 20px;
        }
.lesson_box2 {
            position: absolute;
            top: 5%;
            left: 5%;
            width: 60%;
            height: 75%;
            border: 1px;
            border-radius: 20px;
        }
</style>
<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" />
<div class = "lesson_box"><img src="classes.png" width=100% height=80% class="classes"/></div>
<div class="health_box1"></div>
<link href="css/back_to_frontpage2.css" rel="stylesheet" type="text/css" />
<button type="submit" class='back_to_frontpage2' onclick="window.location.href='main.php'"> 返  回  标  题 </button>
<link href="css/button_system.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button_system' onclick="window.location.href='system.php'"> . </button>
<link href="css/button_save.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button_save' onclick="window.location.href='save_manual.php'"> 存  档 </button>

<p class="wordbox1"></p>
<p class="wordbox2"></p>
<p class="wordbox3"></p>
<p class="wordbox4"></p>
<p class="wordbox5"></p>
<p class="wordbox6"></p>
<p class="wordbox7"></p>
<p class="wordbox8"></p>
<p class="wordbox9"></p>

<?php
session_start();
?>
<script>

var day= <?php echo $_SESSION['day'];?>;
var class1=<?php echo $_SESSION['class'];?>;
var coffee=<?php echo $_SESSION['coffee'];?>;
var life=<?php echo $_SESSION['life'];?>;
var stress=<?php echo $_SESSION['stress'];?>;
var chinese=<?php echo $_SESSION['chinese'];?>;
var maths=<?php echo $_SESSION['maths'];?>;
var english=<?php echo $_SESSION['english'];?>;
var physics=<?php echo $_SESSION['physics'];?>;
var chemistry=<?php echo $_SESSION['chemistry'];?>;
var politics=<?php echo $_SESSION['politics'];?>;
var history1=<?php echo $_SESSION['history'];?>;
var biology=<?php echo $_SESSION['biology'];?>;
var geography=<?php echo $_SESSION['geography'];?>;
var homework=<?php echo $_SESSION['homework'];?>;
var classsleep=<?php echo $_SESSION['classsleep'];?>;
var classnumber=0;
var coffee_task=<?php echo $_SESSION['coffee_task'];?>;
var homework=<?php echo $_SESSION['homework'];?>;
var diligent=<?php echo $_SESSION['diligent'];?>;
var diligent_king=<?php echo $_SESSION['diligent_king'];?>;
var lazy_king=<?php echo $_SESSION['lazy_king'];?>;
var lazy=<?php echo $_SESSION['lazy'];?>;
var diligent_god=<?php echo $_SESSION['diligent_god'];?>;
var lazy_god=<?php echo $_SESSION['lazy_god'];?>;

document.body.innerHTML += '<div class = "lesson_box2"><p style="font-size: 40px; position:absolute; left:20%;"> 距离期中考还有：'+(28-day)+'天 </div>';
ybox();

if(class1==9 ||class1==40){
//pe
document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'pe_truancy.php\'"> 旷课 </button>;<button type="submit" class="homework" onclick="window.location.href=\'pe_stroll.php\'"> 闲逛 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'minorsubject.php\'"> 运动 </button>';
}
else if(class1==10 || class1==21 || class1==32 || class1==43 || class1==54  ){
//nightstudy
document.body.innerHTML +='<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'nightstudy_homework.php\'"> 卷作业 </button>;<button type="submit" class="homework" onclick="window.location.href=\'maincourse_sleep.php\'"> 睡觉 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'nightstudy_chat.php\'"> 聊天 </button>';
}
else if(class1==11 || class1==22 || class1==33 || class1==44 || class1==55  ){
  //nightsleep
  document.body.innerHTML +='<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'nightsleep_homework.php\'"> 卷作业 </button>;<button type="submit" class="homework" onclick="window.location.href=\'nightsleep_sleep.php\'"> 睡觉 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'nightsleep_chat.php\'"> 聊天 </button>';
story_event();  
}
else if(class1==17 || class1==52 ){
    //exam_m
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious_exam" onclick="window.location.href=\'exam_serious_m.php\'"> 认真考试 </button>;<button type="submit" class="lazy_exam" onclick="window.location.href=\'exam_lazy_m.php\'"> 敷衍了事 </button>';
  }
else if(class1==53){
  document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious_exam" onclick="window.location.href=\'exam_serious_e.php\'"> 认真考试 </button>;<button type="submit" class="lazy_exam" onclick="window.location.href=\'exam_lazy_e.php\'"> 敷衍了事 </button>';
}
else{
  document.body.innerHTML +='<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="s_main_course()"> 认真上课 </button>;<button type="submit" class="homework" onclick="h_main_course()"> 卷作业 </button>;<button type="submit" class="sleep" onclick="sl_main_course()"> 睡觉 </button>';
}


document.body.innerHTML += '<div class = "health_box"> <p id="life" style="font-size: 32px; position:absolute; left:7%;"> 生命值：'+life+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="stress" style="font-size: 32px; position:absolute; left:7%; top:10%;"> 压力：'+stress+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="chinese" style="font-size: 28px; position:absolute; left:10%; top:22%;"> 语文：'+chinese+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="maths" style="font-size: 28px; position:absolute; left:50%; top:22%;"> 数学：'+maths+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="english" style="font-size: 28px; position:absolute; left:10%; top:30%;"> 英语：'+english+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="physics" style="font-size: 28px; position:absolute; left:50%; top:30%;"> 物理：'+physics+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="chemistry" style="font-size: 28px; position:absolute; left:10%; top:38%;"> 化学：'+chemistry+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="politics" style="font-size: 28px; position:absolute; left:50%; top:38%;"> 政治：'+politics+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="history" style="font-size: 28px; position:absolute; left:10%; top:46%;"> 历史：'+history1+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="biology" style="font-size: 28px; position:absolute; left:50%; top:46%;"> 生物：'+biology+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="geography" style="font-size: 28px; position:absolute; left:10%; top:54%;"> 地理：'+geography+'</p></div>';
document.body.innerHTML += '<div class = "health_box"> <p id="homework" style="font-size: 33px; position:absolute; left:7%; top:62%;"> 作业完成情况：'+homework+' /100 </p></div>';

//功能函数
function hideElementsByClass(className)
 {
  var elements = document.querySelectorAll('.' + className);
  elements.forEach(function(element) {
    element.style.display = 'none';
  });
}

function getRandomNumber(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

//显示函数
function ybox(){
if(class1==1){
  document.body.innerHTML += '<div id="ybox1" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:28%;"/></div>';
  }
else if(class1==2){
  document.body.innerHTML += '<div id="ybox2" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;"/></div>';
}
else if(class1==3){
  document.body.innerHTML += '<div id="ybox3" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:40.2%;"/></div>';
}
else if(class1==4){
  document.body.innerHTML += '<div id="ybox4" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:46.3%;"/></div>';
}
else if(class1==5){
  document.body.innerHTML += '<div id="ybox5" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:52.4%;"/></div>';
}
else if(class1==6){
  document.body.innerHTML += '<div id="ybox6" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:58.5%;"/></div>';
}
else if(class1==7){
  document.body.innerHTML += '<div id="ybox7" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:65.7%;"/></div>';
}
else if(class1==8){
  document.body.innerHTML += '<div id="ybox8" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:72.3%;"/></div>';
}
else if(class1==9){
  document.body.innerHTML += '<div id="ybox9" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:78.9%;"/></div>';
}
else if(class1==10){
  document.body.innerHTML += '<div id="ybox10" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:85.9%"/></div>';
}
else if(class1==11){
  document.body.innerHTML += '<div id="ybox11" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:92.8%;"/></div>';
}
else if(class1==12){
  document.body.innerHTML += '<div id="ybox12" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:28%;left:17%;"/></div>';
}
else if(class1==13){
  document.body.innerHTML += '<div id="ybox13" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;left:17%;"/></div>';
}
else if(class1==14){
  document.body.innerHTML += '<div id="ybox14" class="lesson_box2"><img src="square.png" width="17%" height="6.5% " style="position:absolute;top:40.2%;left:17%;"/></div>';
}
else if(class1==15){
  document.body.innerHTML += '<div id="ybox15" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:46.3%;left:17%;"/></div>';
}
else if(class1==16){
  document.body.innerHTML += '<div id="ybox16" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:52.4%;left:17%;"/></div>';
}
else if(class1==17){
  document.body.innerHTML += '<div id="ybox17" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:58.5%;left:17%;"/></div>';
}
else if(class1==18){
  document.body.innerHTML += '<div id="ybox18" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:65.7%;left:17%;"/></div>';
}
else if(class1==19){
  document.body.innerHTML += '<div id="ybox19" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:72.3%;left:17%;"/></div>';
}
else if(class1==20){
  document.body.innerHTML += '<div id="ybox20" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:78.9%;left:17%;"/></div>';
}
else if(class1==21){
  document.body.innerHTML += '<div id="ybox21" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:85.9%;left:17%;"/></div>';
}
else if(class1==22){
  document.body.innerHTML += '<div id="ybox22" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:92.8%;left:17%;"/></div>';
}
else if(class1==23){
  document.body.innerHTML += '<div id="ybox23" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:28%;left:34%;"/></div>';
}
else if(class1==24){
  document.body.innerHTML += '<div id="ybox24" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;left:34%;"/></div>';
}
else if(class1==25){
  document.body.innerHTML += '<div id="ybox25" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:40.2%;left:34%;"/></div>';
}
else if(class1==26){
  document.body.innerHTML += '<div id="ybox26" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:46.3%;left:34%;"/></div>';
}
else if(class1==27){
  document.body.innerHTML += '<div id="ybox27" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:52.4%;left:34%;"/></div>';
}
else if(class1==28){
  document.body.innerHTML += '<div id="ybox28" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:58.5%;left:34%;"/></div>';
}
else if(class1==29){
  document.body.innerHTML += '<div id="ybox29" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:65.7%;left:34%;"/></div>';
}
else if(class1==30){
  document.body.innerHTML += '<div id="ybox30" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:72.3%;left:34%;"/></div>';
}
else if(class1==31){
  document.body.innerHTML += '<div id="ybox31" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:78.9%;left:34%;"/></div>';
}
else if(class1==32){
  document.body.innerHTML += '<div id="ybox32" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:85.9%;left:34%;"/></div>';
}
else if(class1==33){
  document.body.innerHTML += '<div id="ybox33" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:92.8%;left:34%;"/></div>';
}
else if(class1==34){
  document.body.innerHTML += '<div id="ybox34" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:28%;left:51%;"/></div>';
}
else if(class1==35){
  document.body.innerHTML += '<div id="ybox35" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;left:51%;"/></div>';
}
else if(class1==36){
  document.body.innerHTML += '<div id="ybox36" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:40.2%;left:51%;"/></div>';
}
else if(class1==37){
  document.body.innerHTML += '<div id="ybox37" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:46.3%;left:51%;"/></div>';
}
else if(class1==38){
  document.body.innerHTML += '<div id="ybox38" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:52.4%;left:51%;"/></div>';
}
else if(class1==39){
  document.body.innerHTML += '<div id="ybox39" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:58.5%;left:51%;"/></div>';
}
else if(class1==40){
  document.body.innerHTML += '<div id="ybox40" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:65.7%;left:51%;"/></div>';
}
else if(class1==41){
  document.body.innerHTML += '<div id="ybox41" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:72.3%;left:51%;"/></div>';
}
else if(class1==42){
  document.body.innerHTML += '<div id="ybox42" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:78.9%;left:51%;"/></div>';
}
else if(class1==43){
  document.body.innerHTML += '<div id="ybox43" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:85.9%;left:51%;"/></div>';
}
else if(class1==44){
  document.body.innerHTML += '<div id="ybox44" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:92.8%;left:51%;"/></div>';
}
else if(class1==45){
  document.body.innerHTML += '<div id="ybox45" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:28%;left:68%;"/></div>';
}
else if(class1==46){
  document.body.innerHTML += '<div id="ybox46" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;left:68%;"/></div>';
}
else if(class1==47){
  document.body.innerHTML += '<div id="ybox47" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:40.2%;left:68%;"/></div>';
}
else if(class1==48){
  document.body.innerHTML += '<div id="ybox48" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:46.3%;left:67%;"/></div>';
}
else if(class1==49){
  document.body.innerHTML += '<div id="ybox49" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:52.4%;left:68%;"/></div>';
}
else if(class1==50){
  document.body.innerHTML += '<div id="ybox50" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:58.5%;left:68%;"/></div>';
}
else if(class1==51){
  document.body.innerHTML += '<div id="ybox51" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:65.7%;left:68%;"/></div>';
}
else if(class1==52){
  document.body.innerHTML += '<div id="ybox52" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:85.9%;right:0%;"/></div>';
}
else if(class1==53){
  document.body.innerHTML += '<div id="ybox53" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:92.8%;right:0%;"/></div>';
}
}

function ybox_change() {
  if (class1 == 1) {
    //显示部分
    var lessonBox1 = document.getElementById('ybox1');
    if (lessonBox1) {
      lessonBox1.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox2" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;"/></div>';
    //if (word1 == 2) {
  //    document.body.innerHTML += '<p id="wordbox1" style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;">考试考了不及格。压力+5</p>';
  //  }
  }
  else if (class1 == 2) {
    var lessonBox2 = document.getElementById('ybox2');
    if (lessonBox2) {
      lessonBox2.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox3" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:40.2%;"/></div>';
  }
  else if (class1 == 3) {
    var lessonBox3 = document.getElementById('ybox3');
    if (lessonBox3) {
      lessonBox3.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox4" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:46.3%;"/></div>';
  }
  else if (class1 == 4) {
    var lessonBox4 = document.getElementById('ybox4');
    if (lessonBox4) {
      lessonBox4.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox5" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:52.4%;"/></div>';

  }
  else if (class1 == 5) {
    var lessonBox5 = document.getElementById('ybox5');
    if (lessonBox5) {
      lessonBox5.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox6" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:58.5%;"/></div>';

  }
  else if (class1 == 6) {
    var lessonBox6 = document.getElementById('ybox6');
    if (lessonBox6) {
      lessonBox6.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox7" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:65.7%;"/></div>';

  }
  else if (class1 == 7) {
    var lessonBox7 = document.getElementById('ybox7');
    if (lessonBox7) {
      lessonBox7.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox8" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:72.3%;"/></div>';

  }
  else if (class1 == 8) {
    var lessonBox8 = document.getElementById('ybox8');
    if (lessonBox8) {
      lessonBox8.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox9" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:78.9%;"/></div>';

    //pe
  }
  else if (class1 == 9) {
    var lessonBox9 = document.getElementById('ybox9');
    if (lessonBox9) {
      lessonBox9.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox10" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:85.9%;"/></div>';

    }
  else if (class1 == 10) {
    var lessonBox10 = document.getElementById('ybox10');
    if (lessonBox10) {
      lessonBox10.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox11" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:92.8%;"/></div>';

    }
  else if (class1 == 11) {
    var lessonBox11 = document.getElementById('ybox11');
    if (lessonBox11) {
      lessonBox11.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox12" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;left:17%;"/></div>';

  }
  else if (class1 == 12) {
    var lessonBox12 = document.getElementById('ybox12');
    if (lessonBox12) {
      lessonBox12.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox13" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;left:17%;"/></div>';

  }
  else if (class1 == 13) {
    var lessonBox13 = document.getElementById('ybox13');
    if (lessonBox13) {
      lessonBox13.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox14" class="lesson_box2"><img src="square.png" width="17%" height="6.5% " style="position:absolute;top:40.2%;left:17%;"/></div>';

  }
  else if (class1 == 14) {
    var lessonBox14 = document.getElementById('ybox14');
    if (lessonBox14) {
      lessonBox14.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox15" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:46.3%;left:17%;"/></div>';
  }
  else if (class1 == 15) {
    var lessonBox15 = document.getElementById('ybox15');
    if (lessonBox15) {
      lessonBox15.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox16" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:52.4%;left:17%;"/></div>';
  }
  else if (class1 == 16) {
    var lessonBox16 = document.getElementById('ybox16');
    if (lessonBox16) {
      lessonBox16.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox17" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:58.5%;left:17%;"/></div>';
  }
  else if (class1 == 17) {
    var lessonBox17 = document.getElementById('ybox17');
    if (lessonBox17) {
      lessonBox17.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox18" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:65.7%;left:17%;"/></div>';
  }
  else if (class1 == 18) {
    var lessonBox18 = document.getElementById('ybox18');
    if (lessonBox18) {
      lessonBox18.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox19" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:72.3%;left:17%;"/></div>';
  }
  else if (class1 == 19) {
    var lessonBox19 = document.getElementById('ybox19');
    if (lessonBox19) {
      lessonBox19.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox20" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:78.9%;left:17%;"/></div>';
  }
  else if (class1 == 20) {
    var lessonBox20 = document.getElementById('ybox20');
    if (lessonBox20) {
      lessonBox20.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox21" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:85.9%;left:17%;"/></div>';
  }
  else if (class1 == 21) {
    var lessonBox21 = document.getElementById('ybox21');
    if (lessonBox21) {
      lessonBox21.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox22" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:92.8%;left:17%;"/></div>';
  }
  else if (class1 == 22) {
    var lessonBox22 = document.getElementById('ybox22');
    if (lessonBox22) {
      lessonBox22.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox23" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:28%;left:34%;"/></div>';
  }
  else if (class1 == 23) {
    var lessonBox23 = document.getElementById('ybox23');
    if (lessonBox23) {
      lessonBox23.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox24" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;left:34%;"/></div>';
  }
  else if (class1 == 24) {
    var lessonBox24 = document.getElementById('ybox24');
    if (lessonBox24) {
      lessonBox24.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox25" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:40.2%;left:34%;"/></div>';
  }
  else if (class1 == 25) {
    var lessonBox25 = document.getElementById('ybox25');
    if (lessonBox25) {
      lessonBox25.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox26" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:46.3%;left:34%;"/></div>';
  }
  else if (class1 == 26) {
    var lessonBox26 = document.getElementById('ybox26');
    if (lessonBox26) {
      lessonBox26.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox27" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:52.4%;left:34%;"/></div>';
  }
  else if (class1 == 27) {
    var lessonBox27 = document.getElementById('ybox27');
    if (lessonBox27) {
      lessonBox27.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox28" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:58.5%;left:34%;"/></div>';
  }
  else if (class1 == 28) {
    var lessonBox28 = document.getElementById('ybox28');
    if (lessonBox28) {
      lessonBox28.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox29" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:65.7%;left:34%;"/></div>';
  }
  else if (class1 == 29) {
    var lessonBox29 = document.getElementById('ybox29');
    if (lessonBox29) {
      lessonBox29.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox30" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:72.3%;left:34%;"/></div>';
  }
  else if (class1 == 30) {
    var lessonBox30 = document.getElementById('ybox30');
    if (lessonBox30) {
      lessonBox30.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox31" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:78.9%;left:34%;"/></div>';
  }
  else if (class1 == 31) {
    var lessonBox31 = document.getElementById('ybox31');
    if (lessonBox31) {
      lessonBox31.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox32" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:85.9%;left:34%;"/></div>';
  }
  else if (class1 == 32) {
    var lessonBox32 = document.getElementById('ybox32');
    if (lessonBox32) {
      lessonBox32.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox33" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:92.8%;left:34%;"/></div>';
  }
  else if (class1 == 33) {
    var lessonBox33 = document.getElementById('ybox33');
    if (lessonBox33) {
      lessonBox33.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox34" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:28%;left:51%;"/></div>';
  }
  else if (class1 == 34) {
    var lessonBox34 = document.getElementById('ybox34');
    if (lessonBox34) {
      lessonBox34.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox35" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;left:51%;"/></div>';
  }
  else if (class1 == 35) {
    var lessonBox35 = document.getElementById('ybox35');
    if (lessonBox35) {
      lessonBox35.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox36" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:40.2%;left:51%;"/></div>';
  }
  else if (class1 == 36) {
    var lessonBox36 = document.getElementById('ybox36');
    if (lessonBox36) {
      lessonBox36.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox37" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:46.3%;left:51%;"/></div>';
  }
  else if (class1 == 37) {
    var lessonBox37 = document.getElementById('ybox37');
    if (lessonBox37) {
      lessonBox37.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox38" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:52.4%;left:51%;"/></div>';
  }
  else if (class1 == 38) {
    var lessonBox38 = document.getElementById('ybox38');
    if (lessonBox38) {
      lessonBox38.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox39" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:58.5%;left:51%;"/></div>';
  }
  else if (class1 == 39) {
    var lessonBox39 = document.getElementById('ybox39');
    if (lessonBox39) {
      lessonBox39.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox40" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:65.7%;left:51%;"/></div>';
  }
  else if (class1 == 40) {
    var lessonBox40 = document.getElementById('ybox40');
    if (lessonBox40) {
      lessonBox40.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox41" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:72.3%;left:51%;"/></div>';
  }
  else if (class1 == 41) {
    var lessonBox41 = document.getElementById('ybox41');
    if (lessonBox41) {
      lessonBox41.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox42" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:78.9%;left:51%;"/></div>';
  }
  else if (class1 == 42) {
    var lessonBox42 = document.getElementById('ybox42');
    if (lessonBox42) {
      lessonBox42.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox43" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:85.9%;left:51%;"/></div>';
  }
  else if (class1 == 43) {
    var lessonBox43 = document.getElementById('ybox43');
    if (lessonBox43) {
      lessonBox43.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox44" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:92.8%;left:51%;"/></div>';
  }
  else if (class1 == 44) {
    var lessonBox44 = document.getElementById('ybox44');
    if (lessonBox44) {
      lessonBox44.style.display = 'none';
    } 
    document.body.innerHTML += '<div id="ybox45" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:28%;left:68%;"/></div>';
  }
  else if (class1 == 45) {
    var lessonBox45 = document.getElementById('ybox45');
    if (lessonBox45) {
      lessonBox45.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox46" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:34.1%;left:68%;"/></div>';
  }
  else if (class1 == 46) {
    var lessonBox46 = document.getElementById('ybox46');
    if (lessonBox46) {
      lessonBox46.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox47" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:40.2%;left:68%;"/></div>';
  }
  else if (class1 == 47) {
    var lessonBox47 = document.getElementById('ybox47');
    if (lessonBox47) {
      lessonBox47.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox48" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:46.3%;left:68%;"/></div>';
  }
  else if (class1 == 48) {
    var lessonBox48 = document.getElementById('ybox48');
    if (lessonBox48) {
      lessonBox48.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox49" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:52.4%;left:68%;"/></div>';
  }
  else if (class1 == 49) {
    var lessonBox49 = document.getElementById('ybox49');
    if (lessonBox49) {
      lessonBox49.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox50" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:58.5%;left:68%;"/></div>';
  }
  else if (class1 == 50) {
    var lessonBox50 = document.getElementById('ybox50');
    if (lessonBox50) {
      lessonBox50.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox51" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:65.7%;left:68%;"/></div>';
  }
  else if (class1 == 51) {
    var lessonBox51 = document.getElementById('ybox51');
    if (lessonBox51) {
      lessonBox51.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox52" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:85.9%;right:0%;"/></div>';
  }
  else if (class1 == 52) {
    var lessonBox52 = document.getElementById('ybox52');
    if (lessonBox52) {
      lessonBox52.style.display = 'none';
    }
    document.body.innerHTML += '<div id="ybox53" class="lesson_box2"><img src="square.png" width="17%" height="6.5%" style="position:absolute;top:92.8%;right:0%;"/></div>';
  }
  else if (class1 == 53) {
    var lessonBox53 = document.getElementById('ybox53');
    if (lessonBox53) {
      lessonBox53.style.display = 'none';
    }
  }
}

//主课系列（按钮直连）
function s_main_course() {
  ybox_change();
  if (class1 == 1) {
    class1+=1;
    //if (word1 == 2) {
  //    document.body.innerHTML += '<p id="wordbox1" style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;">考试考了不及格。压力+5</p>';
  //  }
    classnumber=1;
    maincourse_data();
  }
  else if (class1 == 2) {
    classnumber=3;
    class1+=1;
    maincourse_data();
  }
  else if (class1 == 3) {
    classnumber=2;
    class1+=1;
    maincourse_data();
  }
  else if (class1 == 4) {
    class1+=1;
    classnumber=5;
    maincourse_data();
  }
  else if (class1 == 5) {
    class1+=1;
    classnumber=4;
    maincourse_data();
    special_event();
  
  }
  else if (class1 == 6) {
    minorcourse_data();
    class1+=1;
  }
  else if (class1 == 7) {
    classnumber=7;
    class1+=1;
    maincourse_data();
  }
  else if (class1 == 8) {
    classnumber=9;
    class1+=1;
    maincourse_data();
    //pe
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'pe_truancy.php\'"> 旷课 </button>;<button type="submit" class="homework" onclick="window.location.href=\'pe_stroll.php\'"> 闲逛 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'minorsubject.php\'"> 运动 </button>';
   
  }
  else if (class1 == 12) {
    classnumber=3;
    class1+=1;
    maincourse_data();
  }
  else if (class1 == 13) {
    classnumber=7;
    class1+=1;
    maincourse_data();
  }
  else if (class1 == 14) {
    classnumber=4;
    maincourse_data();
    class1+=1;
  }
  else if (class1 == 15) {
    classnumber=9;
    maincourse_data();
    class1+=1;
  }
  else if (class1 == 16) {
    class1+=1;
    classnumber=6;
    maincourse_data();
    special_event();
    //exam
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious_exam" onclick="window.location.href=\'exam_serious_m.php\'"> 认真考试 </button>;<button type="submit" class="lazy_exam" onclick="window.location.href=\'exam_lazy_m.php\'"> 敷衍了事 </button>';
  }

  else if (class1 == 18) {
    classnumber=8;
    maincourse_data();
    class1+=1;
  }
  else if (class1 == 19) {
    classnumber=1;
    maincourse_data();
    class1+=1;
  }
  else if (class1 == 20) {
    classnumber=5;
    maincourse_data();
    class1+=1;
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'nightstudy_homework.php\'"> 卷作业 </button>;<button type="submit" class="homework" onclick="window.location.href=\'maincourse_sleep.php\'"> 睡觉 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'nightstudy_chat.php\'"> 聊天 </button>';
  }
  else if(class1==23){
    classnumber=2;
    maincourse_data();
    class1+=1;
  }
  else if(class1==24){
    classnumber=4;
    maincourse_data();
    class1+=1;
  }
  else if(class1==25){
    classnumber=7;
    maincourse_data();
    class1+=1;
  }
  else if(class1==26){
    classnumber=1;
    maincourse_data();
    class1+=1;
  }
  else if(class1==27){
    classnumber=6;
    maincourse_data();
    class1+=1;
    special_event();
  }
  else if(class1==28){
    minorcourse_data();
    class1+=1;
  }
  else if(class1==29){
    minorcourse_data();
    class1+=1;
  }
  else if(class1==30){
    classnumber=3;
    maincourse_data();
    class1+=1;
  }
  else if(class1==31){
    classnumber=8;
    maincourse_data();
    class1+=1;
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'nightstudy_homework.php\'"> 卷作业 </button>;<button type="submit" class="homework" onclick="window.location.href=\'maincourse_sleep.php\'"> 睡觉 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'nightstudy_chat.php\'"> 聊天 </button>';
  }
  else if(class1==34){
    classnumber=1;
    maincourse_data();
    class1+=1;
  }
  else if(class1==35){
    classnumber=5;
    maincourse_data();
    class1+=1;
  }
  else if(class1==36){
    classnumber=9;
    maincourse_data();
    class1+=1;
  }
  else if(class1==37){
    classnumber=6;
    maincourse_data();
    class1+=1;
  }
  else if(class1==38){
    classnumber=2;
    maincourse_data();
    class1+=1;
    special_event();
  }
  else if(class1==39){
    classnumber=8;
    maincourse_data();
    class1+=1;
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'pe_truancy.php\'"> 旷课 </button>;<button type="submit" class="homework" onclick="window.location.href=\'pe_stroll.php\'"> 闲逛 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'minorsubject.php\'"> 运动 </button>';
  }
  else if(class1==41){
    classnumber=3;
    maincourse_data();
    class1+=1;
  }
  else if(class1==42){
    minorcourse_data();
    class1+=1;
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'nightstudy_homework.php\'"> 卷作业 </button>;<button type="submit" class="homework" onclick="window.location.href=\'maincourse_sleep.php\'"> 睡觉 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'nightstudy_chat.php\'"> 聊天 </button>';
  }
  else if(class1==45){
    classnumber=2;
    maincourse_data();
    class1+=1;
  }
  else if(class1==46){
    classnumber=4;
    maincourse_data();
    class1+=1;
  }
  else if(class1==47){
    classnumber=6;
    maincourse_data();
    class1+=1;
  }
  else if(class1==48){
    classnumber=7;
    maincourse_data();
    class1+=1;
  }
  else if(class1==49){
    classnumber=5;
    maincourse_data();
    class1+=1;
    special_event();
  }
  else if(class1==50){
    minorcourse_data();
    class1+=1;
  }
  else if(class1==51){
    minorcourse_data();
    class1+=1;
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious_exam" onclick="window.location.href=\'exam_serious_m.php\'"> 认真考试 </button>;<button type="submit" class="lazy_exam" onclick="window.location.href=\'exam_lazy_m.php\'"> 敷衍了事 </button>';
  }
}

function h_main_course(){
  ybox_change();
  class1+=1;

  if(class1==7 || class1==29 || class1==30  || class1==51 ){
    h_minorcourse_data();
  }
  else if(class1==9 || class1==40)
  {hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'pe_truancy.php\'"> 旷课 </button>;<button type="submit" class="homework" onclick="window.location.href=\'pe_stroll.php\'"> 闲逛 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'minorsubject.php\'"> 运动 </button>';
    h_maincourse_data();
  }
  else if(class1==17){
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious_exam" onclick="window.location.href=\'exam_serious_m.php\'"> 认真考试 </button>;<button type="submit" class="lazy_exam" onclick="window.location.href=\'exam_lazy_m.php\'"> 敷衍了事 </button>'; 
    h_maincourse_data();
  }
  else if(class1==52){
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious_exam" onclick="window.location.href=\'exam_serious_m.php\'"> 认真考试 </button>;<button type="submit" class="lazy_exam" onclick="window.location.href=\'exam_lazy_m.php\'"> 敷衍了事 </button>'; 
    h_minorcourse_data();
  }
  else if(class1==32  || class1==21){
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'nightstudy_homework.php\'"> 卷作业 </button>;<button type="submit" class="homework" onclick="window.location.href=\'maincourse_sleep.php\'"> 睡觉 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'nightstudy_chat.php\'"> 聊天 </button>';
    h_maincourse_data();
  }
  else if(class1==43){
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'nightstudy_homework.php\'"> 卷作业 </button>;<button type="submit" class="homework" onclick="window.location.href=\'maincourse_sleep.php\'"> 睡觉 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'nightstudy_chat.php\'"> 聊天 </button>';
    h_minorcourse_data();
  }
  else if (class1 == 6 || class1==17 ||class1==28||class1==39||class1==50) {
    h_maincourse_data();
    special_event();
  }
  else{
    h_maincourse_data();
  }
}

function sl_main_course(){
  ybox_change();
  class1+=1;
  if(class1==7 || class1==29 || class1==31 || class1==51){
    sl_minorcourse_data();
  }
  else if(class1==9 || class1==40)
  {hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'pe_truancy.php\'"> 旷课 </button>;<button type="submit" class="homework" onclick="window.location.href=\'pe_stroll.php\'"> 闲逛 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'minorsubject.php\'"> 运动 </button>';
    sl_maincourse_data();
  }
  else if(class1==17 ){
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious_exam" onclick="window.location.href=\'exam_serious_m.php\'"> 认真考试 </button>;<button type="submit" class="lazy_exam" onclick="window.location.href=\'exam_lazy_m.php\'"> 敷衍了事 </button>'; 
    sl_maincourse_data();
  }
  else if(class1==32  || class1==21){
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'nightstudy_homework.php\'"> 卷作业 </button>;<button type="submit" class="homework" onclick="window.location.href=\'maincourse_sleep.php\'"> 睡觉 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'nightstudy_chat.php\'"> 聊天 </button>';
    sl_maincourse_data();
  }
  else if(class1==52){
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious_exam" onclick="window.location.href=\'exam_serious_m.php\'"> 认真考试 </button>;<button type="submit" class="lazy_exam" onclick="window.location.href=\'exam_lazy_m.php\'"> 敷衍了事 </button>'; 
    sl_minorcourse_data();
  }
  else if(class1==43){
    hideElementsByClass('serious');
    hideElementsByClass('homework');
    hideElementsByClass('sleep');
    document.body.innerHTML += '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" /><button type="submit" class="serious" onclick="window.location.href=\'nightstudy_homework.php\'"> 卷作业 </button>;<button type="submit" class="homework" onclick="window.location.href=\'maincourse_sleep.php\'"> 睡觉 </button>;<button type="submit" class="sleep" onclick="window.location.href=\'nightstudy_chat.php\'"> 聊天 </button>';
    sl_minorcourse_data();
  }
  else if (class1 == 6 || class1==17 ||class1==28||class1==39||class1==50) {
    sl_maincourse_data();
    special_event();
  }
  else{
    sl_maincourse_data();
  }
}

//数据处理
function maincourse_data(){
  hideElementsByClass('wordbox3');
  hideElementsByClass('wordbox4');
  hideElementsByClass('wordbox2');
if (coffee == 0 && life<=50) {
  var randomValue = Math.random(); 
      if (randomValue < 0.4) {
        if(classnumber==1){
          if(chinese<=150){
            chinese+=4;
            life-=5;
            hideElementsByClass('wordbox4');
            if(chinese>=150){
              chinese=150;
              document.getElementById('chinese').innerText = '语文：' + chinese;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }
            document.body.innerHTML += '<div class = "health_box2"><p id="wordbox2" class="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('chinese').innerText = '语文：' + chinese;
            document.getElementById('life').innerText = '生命值：' + life;
          }
          else{
            hideElementsByClass('wordbox2');
            document.body.innerHTML +='<div class = "health_box2"><p id="wordbox4" class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==2){
          if(maths<=150){
            maths+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p id="wordbox2" class="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            console.log('maths updated to:', maths);
            document.getElementById('maths').innerText = maths;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(maths>=150){
              maths=150;
              document.getElementById('maths').innerText = '数学：' + maths;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }
          }
          else{
            hideElementsByClass('wordbox2');
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==3){
          if(english<=150){
            english+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('english').innerText = '英语：' + english;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(english>=150){
              english=150;
              document.getElementById('english').innerText = '英语：' + english;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }
          }
          else{
            var wordbox2 = document.getElementById('wordbox2');
            if (wordbox2) {
              wordbox2.style.display = 'none';
              }
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==4){
          if(physics<=100){
            physics+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p id="wordbox2" class="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('physics').innerText = '物理：' + physics;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(physics>=100){
              physics=100;
              document.getElementById('pysics').innerText = '物理：' + physics;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }
          }
          else{
            hideElementsByClass('wordbox2');
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==5){
          if(chemistry<=100){
            chemistry+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('chemistry').innerText = '化学：' + chemistry;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(chemistry>=100){
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

              chemistry=100;
              document.getElementById('chemistry').innerText = '化学：' + chemistry;
            }
          }
          else{
            hideElementsByClass('wordbox2');
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==6){
          if(politics<=100){
            politics+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('politics').innerText = '政治：' + politics;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(politics>=100){
              politics=100;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

              document.getElementById('politics').innerText = '政治：' + politics;
            }
          }
          else{
            hideElementsByClass('wordbox2');
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==7){
          if(history1<=100){
            history1+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('history').innerText = '历史：' + history1;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(history1>=100){
              history1=100;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

              document.getElementById('history').innerText = '历史：' + history1;
            }
          }
          else{
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
            hideElementsByClass('wordbox2');
          }
        }
        if(classnumber==8){
          if(biology<=100){
            biology+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('biology').innerText = '生物：' + biology;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(biology>=100){
              biology=100;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

              document.getElementById('biology').innerText = '生物：' + biology;
            }
          }
          else{
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
            hideElementsByClass('wordbox2');
              }
          }
        if(classnumber==9){
          if(geography<=100){
            geography+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('geography').innerText = '地理：' + geography;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(geography>=100){
              geography=100;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

              document.getElementById('geography').innerText = '地理：' + geography;
            }
          }
          else{
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
            var wordbox2 = document.getElementById('wordbox2');
            hideElementsByClass('wordbox2');
          }
      }
      hideElementsByClass('wordbox3');
      }
  else {
    life-=1;
        classsleep+=1;
        document.body.innerHTML +='<div class = "health_box2"><p id="wordbox3" class="wordbox3"  style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 一不小心睡着了……生命值-1 </p></div>';
        document.getElementById('life').innerText = '生命值：' + life;
        hideElementsByClass('wordbox2');
        hideElementsByClass('wordbox4');
      }
}
else{
  var randomValue = Math.random(); 
      if (randomValue < 0.6) {
        if(classnumber==1){
          if(chinese<=150){
            chinese+=4;
            life-=5;
            hideElementsByClass('wordbox4');
            if(chinese>=150){
              chinese=150;
              document.getElementById('chinese').innerText = '语文：' + chinese;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }
            else{
            document.body.innerHTML += '<div class = "health_box2"><p id="wordbox2" class="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';}
            document.getElementById('chinese').innerText = '语文：' + chinese;
            document.getElementById('life').innerText = '生命值：' + life;
          }
          else{
            hideElementsByClass('wordbox2');
            document.body.innerHTML +='<div class = "health_box2"><p id="wordbox4" class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==2){
          if(maths<=150){
            maths+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p id="wordbox2" class="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('maths').innerText = '数学：' + maths;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(maths>=150){
              maths=150;
              document.getElementById('maths').innerText = '数学：' + maths;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }
          }
          else{
            hideElementsByClass('wordbox2');
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==3){
          if(english<=150){
            english+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('english').innerText = '英语：' + english;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(english>=150){
              english=150;
              document.getElementById('english').innerText = '英语：' + english;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }
          }
          else{
            var wordbox2 = document.getElementById('wordbox2');
            if (wordbox2) {
              wordbox2.style.display = 'none';
              }
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==4){
          if(physics<=100){
            physics+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p id="wordbox2" class="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('physics').innerText = '物理：' + physics;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(physics>=100){
              physics=100;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

              document.getElementById('pysics').innerText = '物理：' + physics;
            }
          }
          else{
            hideElementsByClass('wordbox2');
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==5){
          if(chemistry<=100){
            chemistry+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('chemistry').innerText = '化学：' + chemistry;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(chemistry>=100){
              chemistry=100;
              document.getElementById('chemistry').innerText = '化学：' + chemistry;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }

          }
          else{
            hideElementsByClass('wordbox2');
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==6){
          if(politics<=100){
            politics+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('politics').innerText = '政治：' + politics;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(politics>=100){
              politics=100;
              document.getElementById('politics').innerText = '政治：' + politics;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }
          }
          else{
            hideElementsByClass('wordbox2');
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
          }
        }
        if(classnumber==7){
          if(history1<=100){
            history1+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('history').innerText = '历史：' + history1;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(history1>=100){
              history1=100;
              document.getElementById('history').innerText = '历史：' + history1;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }
          }
          else{
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
            hideElementsByClass('wordbox2');
          }
        }
        if(classnumber==8){
          if(biology<=100){
            biology+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('biology').innerText = '生物：' + biology;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(biology>=100){
              biology=100;
              document.getElementById('biology').innerText = '生物：' + biology;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

            }
          }
          else{
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
            hideElementsByClass('wordbox2');
              }
          }
        if(classnumber==9){
          if(geography<=100){
            geography+=4;
            life-=5;
            document.body.innerHTML += '<div class = "health_box2"><p class="wordbox2"  id="wordbox2" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+4，生命值-5 </p></div>';
            document.getElementById('geography').innerText = '地理：' + geography;
            document.getElementById('life').innerText = '生命值：' + life;
            hideElementsByClass('wordbox4');
            if(geography>=100){
              geography=100;
              document.body.innerHTML+=     '<div class = "health_box2"><p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';

              document.getElementById('geography').innerText = '地理：' + geography;
            }
          }
          else{
            document.body.innerHTML +='<div class = "health_box2"><p class="wordbox4" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p></div>';
            var wordbox2 = document.getElementById('wordbox2');
            hideElementsByClass('wordbox2');
          }
      }
      hideElementsByClass('wordbox3');
      }
  else {
        life-=1;
        classsleep+=1;
        document.body.innerHTML +='<div class = "health_box2"><p id="wordbox3" class="wordbox3"  style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 一不小心睡着了……生命值-1 </p></div>';
        document.getElementById('life').innerText = '生命值：' + life;
        hideElementsByClass('wordbox2');
        hideElementsByClass('wordbox4');
      }
}
}

function h_maincourse_data(){
        life-=3;
        document.getElementById('life').innerText = '生命值：' + life;
        hideElementsByClass('wordbox2');
        hideElementsByClass('wordbox4');
        hideElementsByClass('wordbox3');
  var randomValue = Math.random(); 
      if (randomValue < 0.6){
        //success
        let randomNumber = getRandomNumber(15, 30);
        homework=homework+randomNumber;
        if(homework>=101){
          window.location.href = 'homework_skip.php';
        }
        else{
          document.body.innerHTML +='<div class = "health_box2"><p id="wordbox3" class="wordbox3"  style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 一节课能写这么多。作业完成度增加，生命值-3  </p></div>';
        }
        document.getElementById('homework').innerText = '作业完成情况：' + homework + '/100';
      }
      else{
        //caught
        stress+=5;
        document.body.innerHTML +='<div class = "health_box2"><p id="wordbox3" class="wordbox3"  style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 啊呀，被老师逮住了。压力+5，生命值-3  </p></div>';
        document.getElementById('stress').innerText = '压力：' + stress;
      }
}

function sl_maincourse_data(){
        hideElementsByClass('wordbox2');
        hideElementsByClass('wordbox4');
        hideElementsByClass('wordbox3');
  var randomValue = Math.random(); 
      if (randomValue < 0.6){
        //success
        life+=15;
        document.body.innerHTML +='<div class = "health_box2"><p id="wordbox3" class="wordbox3"  style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 睡得真爽。生命值+15  </p></div>';
        
        document.getElementById('life').innerText = '生命值：' + life;
      }
      else{
        //caught
        stress+=5;
        life-=3;
        document.body.innerHTML +='<div class = "health_box2"><p id="wordbox3" class="wordbox3"  style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 啊呀，被老师逮住了。压力+5，生命值-3  </p></div>';
        document.getElementById('stress').innerText = '压力：' + stress;
        document.getElementById('life').innerText = '生命值：' + life;
      }
}

function minorcourse_data(){
    hideElementsByClass('wordbox2');
    hideElementsByClass('wordbox4');
    hideElementsByClass('wordbox3');
    stress-=3;
    document.getElementById('stress').innerText = '压力：' + stress; 
    document.body.innerHTML += '<div class = "health_box2"><p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 偶尔上节副科真是太开心了！压力-3 </p></div>';

}

function h_minorcourse_data(){
        life-=3;
        document.getElementById('life').innerText = '生命值：' + life;
        hideElementsByClass('wordbox2');
        hideElementsByClass('wordbox4');
        hideElementsByClass('wordbox3');
        //success
        let randomNumber = getRandomNumber(15, 30);
        homework=homework+randomNumber;
        if(homework>=101){
          window.location.href = 'homework_skip.php';
        }
        else{
          document.body.innerHTML +='<div class = "health_box2"><p id="wordbox3" class="wordbox3"  style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 一节课能写这么多。作业完成度增加，生命值-3  </p></div>';
        }
        document.getElementById('homework').innerText = '作业完成情况：' + homework + '/100';
}

function sl_minorcourse_data(){
        hideElementsByClass('wordbox2');
        hideElementsByClass('wordbox4');
        hideElementsByClass('wordbox3');
        //success
        life+=15;
        document.body.innerHTML +='<div class = "health_box2"><p id="wordbox3" class="wordbox3"  style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 睡得真爽。生命值+15  </p></div>';
        
        document.getElementById('life').innerText = '生命值：' + life;
}

//特殊事件
//coffee
function special_event(){         
    if(classsleep>=3 && coffee_task==0){
      window.location.href = 'coffee.php';
    }
    if(coffee_task==1){
      window.location.href = 'coffee_task.php';
    }
}

//story
function story_event(){         
    if(diligent>=3 && diligent_king==0){
      window.location.href = 'diligent_king.php';
    }
    else if(lazy>=3 && lazy_king==0){
      window.location.href = 'lazy_king.php';
    }
    else if(diligent>=6 && diligent_god==0 && lazy_god==0){
      window.location.href = 'diligent_god.php';
    }
    else if(lazy>=6 && lazy_god==0 && diligent_god==0){
      window.location.href = 'lazy_god.php';
    }
}


//自动存档
window.addEventListener('beforeunload', function (event) {

    sendDataToServer();
});

function sendDataToServer() {
var xhr = new XMLHttpRequest();
xhr.open('POST', 'saveData.php', true);
xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

// 构建请求数据
var data = {
    day: day,
    class: class1,
    chinese: chinese,
    maths: maths,
    english: english,
    physics: physics,
    chemistry: chemistry,
    biology: biology,
    history: history1,
    geography: geography,
    politics: politics,
    homework: homework,
    life: life,
    stress: stress,
    diligent: diligent,
    coffee: coffee,
    coffee_task: coffee_task,
    classsleep: classsleep,
};

var params = [];
for (var key in data) {
    if (data.hasOwnProperty(key)) {
        params.push(key + '=' + encodeURIComponent(data[key]));
    }
}
var postData = params.join('&');

xhr.onreadystatechange = function () {
    if (xhr.readyState === 4 && xhr.status === 200) {
        console.log(xhr.responseText);
    }
};

xhr.send(postData);
}
</script>


<?php

word();
word1();

//显示提示字
function word(){
  if($_SESSION['word']==1){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p>
    </div>';
  }
  elseif($_SESSION['word']==2){
      echo '<div class = "health_box2">
      <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 一不小心睡着了……生命值-1 </p>
      </div>';
  }
  elseif($_SESSION['word']==3){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+5，生命值-5 </p>
    </div>';
  }
  elseif($_SESSION['word']==4){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 一节课能写这么多。作业完成度增加，生命值-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==5){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 啊呀，被老师逮住了。压力+5，生命值-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==6){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 睡得真爽。生命值+15 </p>
    </div>';
  }
  elseif($_SESSION['word']==7){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 偶尔上节副科真是太开心了！压力-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==8){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 啊呀，旷课被抓了……压力+30，处分+1 </p>
    </div>';
  }
  elseif($_SESSION['word']==9){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 逛校园使人快乐。压力-2 </p>
    </div>';
  }
  elseif($_SESSION['word']==10){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 聊天使人快乐。压力-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==11){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 朋友，你见过jiaomin凌晨5点的太阳吗！生命值-30 </p>
    </div>';
  }
  elseif($_SESSION['word']==12){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 聊天使人快乐。压力-6，生命值+10 </p>
    </div>';
  }
  elseif($_SESSION['word']==13){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 一夜好眠。生命+20 </p>
    </div>';
  }
  elseif($_SESSION['word']==15){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 考试好累。生命-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==16){
    echo '<div class = "health_box2">
    <p class="wordbox3" style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 考试睡觉，主打一个自信。 </p>
    </div>';
  }
  $_SESSION['word'] = 0;
}

function word1(){ 
  if($_SESSION['word1']==1){
    echo'<p class="wordbox3"  style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;"> 作业没写完。压力+7 </p>';
  }
  if($_SESSION['word1']==2){
    echo'<p class="wordbox3"  style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;"> 考试考了不及格。压力+5 </p>';
  }
  $_SESSION['word1'] = 0;
}





?>

</body>
<script>


</script>
</html>