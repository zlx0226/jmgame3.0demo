<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life,class,stress,english,day FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $class = $row['class'];
    $stress = $row['stress'];
    $life=$row['life'];
    $english=$row['english'];
    $day=$row['day'];
}


    $life-=3;
    $_SESSION['word']=15;

    if($english<=90){
     $stress+=5;
     $_SESSION['word1']=2;
    }
    else{
        $_SESSION['word1']=0;
       } 

       $english+=3;

       $_SESSION['day'] = $day;
$_SESSION['english'] = $english;
$_SESSION['life']=$life;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;

$sql = "update mytb set life=$life,class=$class,stress=$stress,english=$english,day=$day where name1='$name1'";
$result = $con->query($sql);

echo '<script>window.location.href = "weekend.php";</script>';
?>