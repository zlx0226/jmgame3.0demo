<?php
$servername = "localhost";
$username = "root";
$password = "Zhanglinxuan0226.";
$dbname = "mydb";
// 创建连接
$conn = new mysqli($servername, $username, $password,$dbname);
 
// 检测连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 
echo "连接成功";
mysqli_query($conn , "set names utf8");
$sql = "INSERT INTO mytb (name1, userpassword)
VALUES ('John', 'Doe')";
 
if ($conn->query($sql) === TRUE) {
    echo "新记录插入成功";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
 
$sql = "SELECT id, name1, userpassword FROM mytb";
$result = $conn->query($sql);
 
if ($result->num_rows > 0) {
    // 输出数据
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. "name: " . $row["name1"]. " " ."password: ". $row["userpassword"]. "<br>";

    }
} else {
    echo "0 结果";
}
$conn->close();
?>
