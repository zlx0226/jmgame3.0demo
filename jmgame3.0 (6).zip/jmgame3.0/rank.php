<?php
header('content-type:text/html;charset=utf-8');
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT name1,(COALESCE(ending_1,0) + COALESCE(ending_2,0) + COALESCE(ending_985,0) + COALESCE(ending_211,0) + 
COALESCE(ending_tsinghua,0) + COALESCE(ending_jiaotong,0) + COALESCE(ending_die,0) + COALESCE(ending_nothing,0)
 + COALESCE(ending_jump,0))AS total_ending ,@rank := @rank + 1 AS rank
        FROM 
            mytb, 
            (SELECT @rank := 0) r ORDER BY total_ending DESC";
$result = $con->query($sql);

if ($result === FALSE) {
    echo "查询失败: " . $conn->error;
} else {
    if ($result->num_rows > 0) {
        // 输出数据
        echo "<table border='1'>";
        echo "<tr><th>排名</th><th>用户名</th><th>已解锁结局数</th></tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["rank"] . "</td><td>" . $row["name1"] . "</td><td>" . $row["total_ending"] . "</td></tr>";
        }
        echo "</table>";
    } else {
        echo "没有数据";
    }
}


$sql = "SELECT ending_tsinghua,ending_jiaotong,ending_985,ending_211,ending_1,ending_2,ending_nothing,ending_jump,ending_die
 FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);


// 检查结果并赋值给SESSION变量
if ($result === FALSE) {
    echo "查询失败: " . $con->error;
} else {
if ($result->num_rows > 0) {
    // 获取第一条记录
    $row = $result->fetch_assoc();
    
    // 将查询结果赋值给SESSION变量
    $_SESSION['ending_tsinghua'] = $row['ending_tsinghua'];
    $_SESSION['ending_jiaotong'] = $row['ending_jiaotong'];
    $_SESSION['ending_985'] = $row['ending_985'];
    $_SESSION['ending_211'] = $row['ending_211'];
    $_SESSION['ending_1'] = $row['ending_1'];
    $_SESSION['ending_2'] = $row['ending_2'];
    $_SESSION['ending_nothing'] = $row['ending_nothing'];
    $_SESSION['ending_jump'] = $row['ending_jump'];
    $_SESSION['ending_die'] = $row['ending_die'];

    $tsinghua = '';
    $jiaotong = '';
    $_985 = '';
    $_211 = '';
    $_1 = '';
    $_2 = '';
    $nothing = '';
    $jump = '';
    $die = '';

    if($_SESSION['ending_tsinghua']==1){
        $tsinghua='  清华大学';
    }
    if($_SESSION['ending_jiaotong']==1){
        $jiaotong='  交通大学';
    }
    if($_SESSION['ending_985']==1){
        $_985='  985大学';
    }
    if($_SESSION['ending_211']==1){
        $_211='  211大学';
    }
    if($_SESSION['ending_1']==1){
        $_1='  一本大学';
    }
    if($_SESSION['ending_2']==1){
        $_2='  二本大学';
    }
    if($_SESSION['ending_nothing']==1){
        $nothing='  搬砖去了';
    }
    if($_SESSION['ending_jump']==1){
        $jump='  jumper';
    }
    if($_SESSION['ending_die']==1){
        $die='  R.I.P';
    }
}
}


?>
<link href="css/rank.css" rel="stylesheet" type="text/css" />
<div class = "my_box">
    <p style="font-size: 25px; color:#000000;"> <?php
        echo $name1,'已解锁的结局:',$tsinghua,$jiaotong,$_985,$_211,$_1,$_2,$nothing,$jump,$die;
    ?> </p>
</div> 
<link href="css/creator.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button_back' onclick="window.location.href='main.php'"> 返回 </button>