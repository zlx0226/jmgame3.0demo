<?php
session_start();
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('content-type:text/html;charset=utf-8');
require 'database_connect.php';

$name1=$_SESSION['username'];

// 检查是否是 POST 请求
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 直接获取表单数据并存储在变量中
    $day = $_POST['day'];
    $class = $_POST['class'];
    $chinese = $_POST['chinese'];
    $maths = $_POST['maths'];
    $english = $_POST['english'];
    $physics = $_POST['physics'];
    $chemistry = $_POST['chemistry'];
    $biology = $_POST['biology'];
    $history = $_POST['history'];
    $geography = $_POST['geography'];
    $politics = $_POST['politics'];
    $homework = $_POST['homework'];
    $life = $_POST['life'];
    $stress = $_POST['stress'];
    $diligent = $_POST['diligent'];
    $coffee = $_POST['coffee'];
    $coffee_task = $_POST['coffee_task'];
    $classsleep = $_POST['classsleep'];

    // 进行后续处理，例如保存到数据库
    // 示例：$stmt->bind_param("sssssssssssssssss", $day, $class, $chinese, $maths, $english, $physics, $chemistry, $biology, $history, $geography, $politics, $homework, $life, $stress, $diligent, $coffee, $coffee_task, $classsleep, $name1);

    echo json_encode(['success' => true, 'message' => '数据提交成功']);
} else {
    echo json_encode(['success' => false, 'message' => '请使用POST方法提交数据']);
}

$_SESSION['day']=$day;
$_SESSION['class'] = $class;
$_SESSION['chinese'] = $chinese;
$_SESSION['maths'] = $maths;
$_SESSION['english'] = $english;
$_SESSION['physics'] = $physics;
$_SESSION['chemistry'] = $chemistry;
$_SESSION['biology'] = $biology;
$_SESSION['history'] = $history;
$_SESSION['geography'] = $geography;
$_SESSION['politics'] = $politics;
$_SESSION['homework'] = $homework;
$_SESSION['life'] = $life;
$_SESSION['stress'] = $stress;
$_SESSION['diligent'] = $diligent;
$_SESSION['coffee'] = $coffee;
$_SESSION['coffee_task'] = $coffee_task;
$_SESSION['classsleep'] = $classsleep;

$sql = "update mytb set life=$life,day=$day,class=$class,coffee_task=$coffee_task,coffee=$coffee,stress=$stress,classsleep=$classsleep,homework=$homework,diligent=$diligent,chinese=$chinese,maths=$maths,english=$english,physics=$physics,chemistry=$chemistry,biology=$biology,politics=$politics,history=$history,geography=$geography where name1='$name1'";
$result = $con->query($sql);
if (!$result) {
  // 打印错误信息
  echo "Error: " . $con->error;}
?>

