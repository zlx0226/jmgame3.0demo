<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body >
<style>
    body {
      background-image: url("cover.jpg");
      background-size: cover;
      background-repeat: no-repeat;
    }
  </style>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls autoplay></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<link href="css/button1.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button1' onclick="window.location.href='newgame_new.php'">开  始  新  游  戏</button>
<link href="css/button_continue.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button_continue' onclick="window.location.href='read_auto.php'"> 继  续  游  戏 </button>
<link href="css/button_system.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button_system' onclick="window.location.href='system.php'"> . </button>
<link href="css/rank.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button_rank' onclick="window.location.href='rank.php'"> 全  服  排  名 </button>
</body>
<script>
</script>
</html>

