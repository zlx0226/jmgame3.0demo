<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT coffee,coffee_task FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $coffee = $row['coffee'];
    $coffee_task=$row['coffee_task'];
}

    $coffee_task=2;
    $coffee=1;

$_SESSION['coffee_task']=$coffee_task;
$_SESSION['coffee']=$coffee;

$sql = "update mytb set coffee=$coffee,coffee_task=$coffee_task where name1='$name1'";
$result = $con->query($sql);
?>

<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls autoplay></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<style>
        body {
              background-image: url("classroom.jpg");
              background-size:100%;
              background-attachment: fixed;
              background-repeat: no-repeat;
            }
        </style>
<link href="css/coffee_game.css" rel="stylesheet" type="text/css" />
<img src="coffee.jpg" width=70% class="picture1"/>
<link href="css/caught.css" rel="stylesheet" type="text/css" />
<div class = "word_box1">
    <p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;这个月的咖啡不用愁了！（上课睡觉概率减小） </p>
</div> 

<button type="submit" class='button_continue' onclick="window.location.href='read_auto.php'">  </button>
</body>
</html>