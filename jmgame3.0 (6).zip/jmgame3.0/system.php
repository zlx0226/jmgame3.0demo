<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body >
<audio id="music" src="music.m4a" hidden="true" loop="loop" controls autoplay></audio>
<script>
var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }  
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
  
  function muteAllSounds() {
    sessionStorage.setItem('musicOn', '0'); 
    const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }  
};
function onAllSounds() {  
  sessionStorage.setItem('musicOn', '1'); 
    const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = false;  
    }  
}  
</script>
<style>
body {
      background-image: url("background_system2.jpg");
      background-size:100%;
      background-attachment: fixed;
      background-repeat: no-repeat;
    }
</style>

<p style="font-size: 25px;"> 提出建议：https://www.wjx.cn/vm/O0QMtoP.aspx
 </p>
<link href="css/back_to_frontpage.css" rel="stylesheet" type="text/css" />
<link href="css/system.css" rel="stylesheet" type="text/css" />

<div class = "title_box">
<p style="font-size: 60px; color:#3d2311;">  设&nbsp;&nbsp;置 </p>
</div> 

<div class = "main_box">
<p style="font-size: 35px;">  用户名：&nbsp; <?php session_start(); echo $_SESSION['username'];?> </p>
<p style="font-size: 35px;"> 声音： </p>
</div> 

<div class = "warning_box">
<p style="font-size: 35px; color: blue;"> 注意： </p>
<p style="font-size: 20px;"> 1、建议电脑全屏游玩，否则个别地方显示可能会有问题 </p>
<p style="font-size: 20px;"> 2、“读档”读取的是手动存档，其余读取的都是自动存档，读档后手动
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 存档的数据会覆盖原来自动存档的数据</p>
<p style="font-size: 20px;"> 3、背景音乐可能需要一定时间加载，关闭声音后再开声音需要退出此<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;页面后才会响应 </p>
<p style="font-size: 20px;"> 4、本游戏中的一些情节可能取材于现实，但都已经过艺术加工，与一<br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;切真实团体、个人无关 </p>
<p style="font-size: 20px;"> 5、更多游戏攻略或问题请阅读设置界面右上角的 “攻略&注意事项”，<br>
&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;如仍无法解决，请向客服咨询，联系方式请见右上角 </p>
</div> 

<button type="submit" class='button_back' onclick="window.location.href='read_auto.php'"> 继&nbsp;&nbsp;续
 &nbsp;&nbsp;游&nbsp;&nbsp;戏 </button>
<button type="submit" class='button_creator' onclick="window.location.href='creator.html'"> 制&nbsp;&nbsp;作
 &nbsp;&nbsp;人&nbsp;&nbsp;员 </button>
<button type="submit" class='button_read'  onclick="window.location.href='read_manual.php'"> 读&nbsp;&nbsp;档 </button>
<button type="submit" class='button_task' onclick="alert('敬请期待')"> 任&nbsp;&nbsp;务
 &nbsp;&nbsp;&&nbsp;&nbsp;成&nbsp;&nbsp;就 </button>
<button type="submit" class='button_warning' onclick="window.location.href='warning.html'"> 攻略&注意事项 </button>
<button type="submit" class='back_to_frontpage' onclick="window.location.href='main.php'"> 返  回  标  题 </button>
<button type="submit" class='button_musicoff' onclick="muteAllSounds() "> 关 </button>
<button type="submit" class='button_musicon' onclick="onAllSounds() "> 开 </button>
</body>
<script>
</script>
</html>