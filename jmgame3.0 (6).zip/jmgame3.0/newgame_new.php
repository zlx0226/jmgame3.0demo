<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body >
<style>
 body {
      background-image: url("newgame_new.jpg");
      background-size: cover;
      background-repeat: no-repeat;
    }

</style>
<audio id="music" src="music.m4a" loop="loop" hidden="true" controls autoplay></audio>

<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }  
 
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>

<link href="css/button1_1.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button1_1' > <?php session_start(); echo $_SESSION['username'];?> </button>
<link href="css/button_newgame.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button_newgame' onclick="window.location.href='newgame_start.php'" > 入  学 </button>
<link href="css/back_to_frontpage3.css" rel="stylesheet" type="text/css" />
<button type="submit" class='back_to_frontpage3' onclick="window.location.href='main.php'" > 我后悔了 </button>

</body>
<script>
</script>
</html>