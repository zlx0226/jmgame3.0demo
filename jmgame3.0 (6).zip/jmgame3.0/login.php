<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body >
<?php
header('content-type:text/html;charset=utf-8');
require 'database_connect.php';

$name1 =$_POST['login_username'];
$userpassword =$_POST['login_password'];
$sql="select id,name1,userpassword from mytb where name1='$name1' and userpassword='$userpassword';";
$result=mysqli_query($con, $sql);//执行sql语句
$row=mysqli_num_rows($result);//返回值条目
if (!$row){//若返回条目不存在则证明该账号不存在或者密码输入错误
    echo "账号不存在或密码错误，点击前往注册";
        //exit('账号或密码错误');
    echo "<button type='submit' onclick='window.location.href=\"login.html\"'> 返回 </button>";
        }
else{//存在返回条目证明用户账号密码匹配，进入主页面
    echo "欢迎登录交闵小游戏3.0！";
    $length = mb_strlen($name1, 'utf-8');
    $arr = [];
    for ($i=0; $i<$length; $i++)  
    {
    $arr[] = mb_substr($name1, $i, 1, 'utf-8');    
    }
    //print_r($arr);
    $i=0;
    $count=count($arr);
    while($i<=count($arr))
    {
        $i1=$i+1;
        $i2=$i+2;
        if($arr[$i]=='王' and $arr[$i1]=='健'){
            session_start();
            $_SESSION['specialname']=1;
            echo '你小子胆儿挺大 <br>' ;
            echo '<img src="wangjian.jpg" width=50% height=50%/>';
        }
        elseif($arr[$i]=='范' and $arr[$i1]=='红' and $arr[$i2]=='凤'){
            session_start();
            $_SESSION['specialname']=2;
            echo '你小子胆儿挺大';
        }

    $i++;
    }
    //if($_SESSION['specialname']==1){echo '你小子胆儿挺大 <br>' ;
    //echo '<img src="wangjian.jpg" width=50% height=50%/>';}
    //if($_SESSION['specialname']==2){echo '你小子胆儿挺大';}
    session_start();
    $_SESSION['username']= $name1;
    echo "<button type='submit' onclick='window.location.href=\"main.php\"'> 继续 </button>";
  
       
} 
?>
<script>
    sessionStorage.setItem('musicOn', '1'); 
</script>
</body>