<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT diligent_king, diligent_king_achieve FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $diligent_king = $row["diligent_king"];
    $diligent_king_achieve = $row["diligent_king_achieve"];
}

$diligent_king=1;
$_SESSION['diligent_king'] = $diligent_king;
$diligent_king_achieve = 1;
$_SESSION['diligent_king_achieve'] = $diligent_king_achieve;


$sql = "update mytb set diligent_king=$diligent_king, diligent_king_achieve=$diligent_king_achieve where name1='$name1'";
$result = $con->query($sql);
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls ></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<style>
        body {
              background-image: url("classroom.jpg");
              background-size:100%;
              background-attachment: fixed;
              background-repeat: no-repeat;
            }
        </style>
<link href="css/caught.css" rel="stylesheet" type="text/css" />
<div class = "word_box">
    <div class="name_box">
        <p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;室友A </p>
    </div>
    <p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;bro，一起出去倒水不？ </p>
</div> 
<img src="roommate_a.png" width=43%  class="picture"/>

<button type="submit" class='button_continue' onclick="c1()">  </button>
<script>
function hideElementsByClass(className)
 {
  var elements = document.querySelectorAll('.' + className);
  elements.forEach(function(element) {
    element.style.display = 'none';
  });
}

function c1(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;不了，不了。我要写作业！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c2()">  </button>';
   }
function c2(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
     document.body.innerHTML += '<img src="roommate_a.png" width=43%  class="picture"/>'
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;室友A </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;嘿，让我看看你的作业写到哪儿了！（凑近一看） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c3()">  </button>';
   }
 function c3(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="roommate_a_angry.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;室友A </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;什么！你的作业已经写完了！那你在写什么！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c4()">  </button>';
 }
 function c4(){
  hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;没什么，没什么！你看我明天的跬步都没写。清清白白！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c5()">  </button>';
 }
 function c5(){
    hideElementsByClass("words");
    document.body.innerHTML += '<img src="student_wangguihua.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;王桂花 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;你往后翻一页！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c6()">  </button>';
 }
 function c6(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;哎呀！别别别，没什么，没什么的！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c7()">  </button>';
 }
 function c7(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="roommate_a_angry.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;室友A </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;翻！（往后翻了一页） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c8()">  </button>';
 }
 function c8(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;………… </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c9()">  </button>';
 }
 function c9(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="student_wangguihua_angry.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;王桂花 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;果然！你怕被我们说，跳过明天，把后天的跬步写完了！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c10()">  </button>';
 }
 function c10(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="roommate_a_angry.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;室友A </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp大后天的也写完了！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c11()">  </button>';
 }
 function c11(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="student_wangguihua_angry.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;王桂花 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;一周的跬步都写完了！！！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c12()">  </button>';
 }
 function c12(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="roommate_a_angry.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;室友A </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;卷狗！！！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c13()">  </button>';
 }
 function c13(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="student_wangguihua_angry.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;王桂花 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;卷狗！！！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c14()">  </button>';
 }
 function c14(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;解锁成就“卷狗”！（每天压力-3，生命-3）（改编自历史真实事件：）） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="window.location.href=\'read_auto.php\'">  </button>';
 }


</script>

</body>
</html>