<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT diligent FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $diligent=$row['diligent'];
}
$diligent+=1;
$_SESSION['diligent']=$diligent;

$sql = "update mytb set diligent=$diligent where name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}

echo '<script>window.location.href = "read_auto.php";</script>';
?>