<?php
header('content-type:text/html;charset=utf-8');
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life2, day2, week2, class2, hospital2, music2, coffee_task2, coffee2, stress2, warning2, noodle_task2, noodle_day2, classsleep2, homework2, diligent2, lazy2, diligent_king2, diligent_god2, lazy_king2, lazy_god2, lovers2, lovers_talkleft2, lovers_talkright2, singer2, lastdinner2, domitoryhomework2, chinese2, maths2, english2, physics2, chemistry2, biology2, politics2, history2, geography2
 FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}

// 检查结果并赋值给SESSION变量
while($row = $result->fetch_assoc()){
    
    // 将查询结果赋值给SESSION变量
    $_SESSION['life'] = $row['life2'];
    $_SESSION['day'] = $row['day2'];
    $_SESSION['week'] = $row['week2'];
    $_SESSION['class'] = $row['class2'];
    $_SESSION['music'] = $row['music2'];
    $_SESSION['coffee_task'] = $row['coffee_task2'];
    $_SESSION['coffee'] = $row['coffee2'];
    $_SESSION['stress'] = $row['stress2'];
    $_SESSION['warning'] = $row['warning2'];
    $_SESSION['noodle_task'] = $row['noodle_task2'];
    $_SESSION['noodle_day'] = $row['noodle_day2'];
    $_SESSION['classsleep'] = $row['classsleep2'];
    $_SESSION['homework'] = $row['homework2'];
    $_SESSION['diligent'] = $row['diligent2'];
    $_SESSION['lazy'] = $row['lazy2'];
    $_SESSION['diligent_king'] = $row['diligent_king2'];
    $_SESSION['diligent_god'] = $row['diligent_god2'];
    $_SESSION['lazy_king'] = $row['lazy_king2'];
    $_SESSION['lazy_god'] = $row['lazy_god2'];
    $_SESSION['lovers'] = $row['lovers2'];
    $_SESSION['lovers_talkleft'] = $row['lovers_talkleft2'];
    $_SESSION['lovers_talkright'] = $row['lovers_talkright2'];
    $_SESSION['singer'] = $row['singer2'];
    $_SESSION['lastdinner'] = $row['lastdinner2'];
    $_SESSION['domitoryhomework'] = $row['domitoryhomework2'];
    $_SESSION['chinese'] = $row['chinese2'];
    $_SESSION['maths'] = $row['maths2'];
    $_SESSION['english'] = $row['english2'];
    $_SESSION['physics'] = $row['physics2'];
    $_SESSION['chemistry'] = $row['chemistry2'];
    $_SESSION['biology'] = $row['biology2'];
    $_SESSION['politics'] = $row['politics2'];
    $_SESSION['history'] = $row['history2'];
    $_SESSION['geography'] = $row['geography2'];
}

$life = $_SESSION['life'];
$day = $_SESSION['day'];
$week = $_SESSION['week'];
$class = $_SESSION['class'];
$music = $_SESSION['music'];
$hospital = $_SESSION['hospital'];
$coffee_task = $_SESSION['coffee_task'];
$coffee = $_SESSION['coffee'];
$stress = $_SESSION['stress'];
$warning = $_SESSION['warning'];
$noodle_task = $_SESSION['noodle_task'];
$noodle_day = $_SESSION['noodle_day'];
$classsleep = $_SESSION['classsleep'];
$homework = $_SESSION['homework'];
$diligent = $_SESSION['diligent'];
$lazy = $_SESSION['lazy'];
$diligent_king = $_SESSION['diligent_king'];
$diligent_god = $_SESSION['diligent_god'];
$lazy_king = $_SESSION['lazy_king'];
$lazy_god = $_SESSION['lazy_god'];
$lovers = $_SESSION['lovers'];
$lovers_talkleft = $_SESSION['lovers_talkleft'];
$lovers_talkright = $_SESSION['lovers_talkright'];
$singer = $_SESSION['singer'];
$lastdinner = $_SESSION['lastdinner'];
$domitoryhomework = $_SESSION['domitoryhomework'];
$chinese = $_SESSION['chinese'];
$maths = $_SESSION['maths'];
$english = $_SESSION['english'];
$physics = $_SESSION['physics'];
$chemistry = $_SESSION['chemistry'];
$biology = $_SESSION['biology'];
$politics = $_SESSION['politics'];
$history = $_SESSION['history'];
$geography = $_SESSION['geography'];

$sql = "UPDATE mytb SET 
        hospital = '".$hospital."',
        life = '".$life."',
        day = '".$day."',
        week = '".$week."',
        class = '".$class."',
        music = '".$music."',
        coffee_task = '".$coffee_task."',
        coffee = '".$coffee."',
        stress = '".$stress."',
        warning = '".$warning."',
        noodle_task = '".$noodle_task."',
        noodle_day = '".$noodle_day."',
        classsleep = '".$classsleep."',
        homework = '".$homework."',
        diligent = '".$diligent."',
        lazy = '".$lazy."',
        diligent_king = '".$diligent_king."',
        diligent_god = '".$diligent_god."',
        lazy_king = '".$lazy_king."',
        lazy_god = '".$lazy_god."',
        lovers = '".$lovers."',
        lovers_talkleft = '".$lovers_talkleft."',
        lovers_talkright = '".$lovers_talkright."',
        singer = '".$singer."',
        lastdinner = '".$lastdinner."',
        domitoryhomework = '".$domitoryhomework."',
        chinese = '".$chinese."',
        maths = '".$maths."',
        english = '".$english."',
        physics = '".$physics."',
        chemistry = '".$chemistry."',
        biology = '".$biology."',
        politics = '".$politics."',
        history = '".$history."',
        geography = '".$geography."'
    WHERE name1 = '".$name1."'";
$result = $con->query($sql);
//$sql = "update mytb set hospital=$hospital,life=$life,day=$day,week=$week,class=$class,music=$music,coffee_task=$coffee_task,coffee=$coffee,stress=$stress,warning=$warning,noodle_task=$noodle_task,noodle_day=$noodle_day,classsleep=$classsleep,homework=$homework,diligent=$diligent,lazy=$lazy,diligent_king=$diligent_king,diligent_god=$diligent_god,lazy_king=$lazy_king,lazy_god=$lazy_god,lovers=$lovers,lovers_talkleft=$lovers_talkleft,lovers_talkright=$lovers_talkright,singer=$singer,lastdinner=$lastdinner,domitoryhomework=$domitoryhomework,chinese=$chinese,maths=$maths,english=$english,physics=$physics,chemistry=$chemistry,biology=$biology,politics=$politics,history=$history,geography=$geography where name1=$name1";
//$result = $con->query($sql);
if (!$result) {
  // 打印错误信息
  echo "Error: " . $con->error;}


  echo '<script>window.location.href = "newgame_basic.php";</script>';

?>