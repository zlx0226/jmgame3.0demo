
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls ></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<style>
        body {
              background-image: url("classroom.jpg");
              background-size:100%;
              background-attachment: fixed;
              background-repeat: no-repeat;
            }
        </style>
<link href="css/caught.css" rel="stylesheet" type="text/css" />
<div class = "word_box">
    <p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;午饭时间到！是否前往抢购贝纳颂： </p>
</div> 
<link href="css/pe_stroll_cat.css" rel="stylesheet" type="text/css" />

<button type="submit" class='button_head' onclick="window.location.href='coffee_play_pre.html'"> 是 </button>
<button type="submit" class='button_stomach' onclick="window.location.href='read_auto.php'"> 否 </button>

<script>

</script>

</body>
</html>