<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life,class FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $class = $row['class'];
    $life=$row['life'];
}

$_SESSION['word']=13;
$life+=20;
$_SESSION['life']=$life;
$_SESSION['class']=$class;

$sql = "update mytb set life=$life,class=$class where name1='$name1'";
$result = $con->query($sql);

echo '<script>window.location.href = "dayend.php";</script>';
?>