<!DOCTYPE html>
<html>
<head>
    <title>物体碰撞检测</title>
    <style>
       canvas {
            border: 1px solid black;
            background-image: url('canteen.png'); /* 设置背景图片 */
            background-size: cover; /* 使背景图片覆盖整个canvas */
            background-repeat: no-repeat; /* 防止背景图片重复 */
        }

    </style>
</head>
<body>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls ></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
    <canvas id="gameCanvas" width="1350" height="760"></canvas>
    <link href="css/coffee_game.css" rel="stylesheet" type="text/css" />

<button type="submit" class='button_l' onclick="button_l()"> 左 </button>
<button type="submit" class='button_r' onclick="button_r()"> 右 </button>
    <script>
        var gameStartTime = Date.now();
        // 获取canvas元素和上下文
        var canvas = document.getElementById('gameCanvas');
        var ctx = canvas.getContext('2d');

        // 定义矩形物体
        var rect1 = {
            x: 625,
            y: 450,
            width: 120,
            height: 140,
            image: new Image()
        };
        rect1.image.src = 'me.png';
        //小怪1
        var rects = [];
for (var i = 0; i < 6; i++) {
    rects.push({
        x: (50 + Math.random() * 1150),
        y: -50,
        width: 120,
        height: 140,
        image: new Image(),
        speed: (1 + 3*Math.random()) * 50 / 1000, // 每秒移动
        isMoving: true
    });
    rects[i].image.src = 'enemy.png'; // 设置图片路径
}
//小怪2（3秒后出现）
var rects2 = [];
setTimeout(function() {
    for (var m = 0; m < 5; m++) {
    rects2.push({
        x: (70 + Math.random() * 1150),
        y: -50,
        width: 120,
        height: 140,
        image: new Image(),
        speed: (1 + 1.5*Math.random()) * 50 / 1000, // 每秒移动
        isMoving: true
    });
    rects2[m].image.src = 'enemy2.png'; // 设置图片路径
}
    }, 3000);

//小怪3（8秒后出现）
var rects3 = [];
setTimeout(function() {
    for (var n = 0; n < 2; n++) {
    rects3.push({
        x: (rect1.x-200 + Math.random() * 400),
        y: -50,
        width: 120,
        height: 140,
        image: new Image(),
        speed: (2 + 3*Math.random()) * 50 / 1000, // 每秒移动
        isMoving: true
    });
    rects3[n].image.src = 'enemy3.png'; // 设置图片路径
}
    }, 8000);

        function drawRect(rect) {
    if (rect.image) {
        ctx.drawImage(rect.image, rect.x, rect.y, rect.width, rect.height);
    } else {
        ctx.fillStyle = rect.color || 'black';
        ctx.fillRect(rect.x, rect.y, rect.width, rect.height);
    }
}

       // 检测碰撞 (横向缩小0.5，纵向缩小0.1)
function checkCollision(rect1, rect2) {
    if (!rect1 || !rect2) return false;
    
    // 定义横向和纵向不同的缩小比例
    const shrinkWidth = 0.5;  // 横向缩小50%
    const shrinkHeight = 0.1; // 纵向缩小10%
    
    // 计算缩小后的碰撞箱尺寸
    const rect1Width = rect1.width * (1 - shrinkWidth);
    const rect1Height = rect1.height * (1 - shrinkHeight);
    const rect2Width = rect2.width * (1 - shrinkWidth);
    const rect2Height = rect2.height * (1 - shrinkHeight);
    
    // 计算中心点偏移
    const rect1X = rect1.x + (rect1.width - rect1Width) / 2;
    const rect1Y = rect1.y + (rect1.height - rect1Height) / 2;
    const rect2X = rect2.x + (rect2.width - rect2Width) / 2;
    const rect2Y = rect2.y + (rect2.height - rect2Height) / 2;
    
    return rect1X < rect2X + rect2Width &&
           rect1X + rect1Width > rect2X &&
           rect1Y < rect2Y + rect2Height &&
           rect1Y + rect1Height > rect2Y;
}

// 主游戏循环
function gameLoop(timestamp) {
            if (!lastTime) lastTime = timestamp;
            var deltaTime = timestamp - lastTime;
            lastTime = timestamp;
// 清除画布
ctx.clearRect(0, 0, canvas.width, canvas.height);
            var currentTime = Date.now();
    if (currentTime - gameStartTime >=30000) {
        document.body.innerHTML += '<div class="word_box"><p class="words" style="font-size: 100px; color:red;"> YOU WIN! </p></div>';
            document.body.innerHTML += '<button type="submit" class="button_continue" onclick="window.location.href=\'coffee_win.php\'"> . </button>';
        return;
    }
        // 更新倒计时显示
        var elapsed = Date.now() - gameStartTime;
    var remaining = Math.max(0, 30000 - elapsed);

       // 绘制倒计时（放在正上方中央，加大字体）
    ctx.fillStyle = 'rgba(0,0,0,0.7)'; // 半透明黑色背景
    var text = '剩余时间: ' + (remaining/1000).toFixed(1) + '秒';
    var textWidth = ctx.measureText(text).width;
    
    // 绘制背景框（宽度自适应文字）
    ctx.fillRect(canvas.width/2 - textWidth/2 - 15, 10, textWidth + 30, 50);
    
    // 设置字体样式
    ctx.fillStyle = 'white';
    ctx.font = 'bold 36px Arial'; // 加粗，36像素大小
    ctx.textAlign = 'center';
    ctx.textBaseline = 'top';
    
    // 绘制倒计时文字（居中显示）
    ctx.fillText(text, canvas.width/2, 20);
    
    // 恢复默认文本对齐方式（以免影响其他文字）
    ctx.textAlign = 'left';
    ctx.textBaseline = 'alphabetic';

            // 更新所有rect2的位置
        rects.forEach(function(rect) {
            if (rect.isMoving) {
                rect.y += rect.speed * deltaTime;
                
                // 如果rect2落到底部，重新从顶部开始
                if (rect.y > canvas.height) {
                    rect.y = -140;
                    rect.x = (10 + Math.random() * 1320);
                }
            }
        });
        rects2.forEach(function(rect) {
            if (rect.isMoving) {
                rect.y += rect.speed * deltaTime;
                
                // 如果rects2落到底部，重新从顶部开始
                if (rect.y > canvas.height) {
                    rect.y = -140;
                    rect.x = (10 + Math.random() * 1320);
                }
            }
        });
        rects3.forEach(function(rect) {
            if (rect.isMoving) {
                rect.y += rect.speed * deltaTime;
                
                // 如果rects3落到底部，重新从顶部开始
                if (rect.y > canvas.height) {
                    rect.y = -140;
                    rect.x = (rect1.x-200 + Math.random() * 400);
                }
            }
        });

            // 绘制物体
            drawRect(rect1);
            rects.forEach(function(rect) {
            drawRect(rect);
        });
        rects2.forEach(function(rect) {
            drawRect(rect);
        });
        rects3.forEach(function(rect) {
            drawRect(rect);
        });
                // 检测碰撞
        var collisionDetected = false;
        rects.forEach(function(rect) {
            if (rect1 && rect && checkCollision(rect1, rect)) {
                collisionDetected = true;
                rect.isMoving = false;
            }
        });
        rects2.forEach(function(rect) {
            if (rect1 && rect && checkCollision(rect1, rect)) {
                collisionDetected = true;
                rect.isMoving = false;
            }
        });
        rects3.forEach(function(rect) {
            if (rect1 && rect && checkCollision(rect1, rect)) {
                collisionDetected = true;
                rect.isMoving = false;
            }
        });

        if (collisionDetected) {
            ctx.fillStyle = 'green';
            ctx.fillText('碰撞检测: 碰撞发生', 10, 30);
            document.body.innerHTML += '<div class="word_box"><p class="words" style="font-size: 70px; color:red;"> YOU FAIL! </p></div>';
            document.body.innerHTML += '<button type="submit" class="button_continue" onclick="window.location.href=\'read_auto.php\'"> . </button>';
    return;
        } 
        else {
            ctx.fillStyle = 'green';
            ctx.fillText('碰撞检测: 无碰撞', 10, 30);
        }
            // 请求下一帧
            requestAnimationFrame(gameLoop);
        }

function button_l(){
    rect1.x = rect1.x - 50;
};
function button_r(){
    rect1.x = rect1.x + 50;
};

var imagesLoaded = 0;
    function checkImagesLoaded() {
        imagesLoaded++;
        if (imagesLoaded == (1 + rects.length+rects2.length)) {
            requestAnimationFrame(gameLoop);
        }
    }

    rect1.image.onload = checkImagesLoaded;
    rects.forEach(function(rect) {
        rect.image.onload = checkImagesLoaded;
    });
    rects2.forEach(function(rect) {
        rect.image.onload = checkImagesLoaded;
    });
    rects3.forEach(function(rect) {
        rect.image.onload = checkImagesLoaded;
    });
    var lastTime = 0;
    </script>
</body>
</html>