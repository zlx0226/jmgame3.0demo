<?php
header('content-type:text/html;charset=utf-8');
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$classnumber=$_SESSION['classnumber'];
$sql = "SELECT chinese,maths,english,physics,chemistry,biology,politics,history,geography FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $chinese = $row['chinese'];
    $maths = $row['maths'];
    $english = $row['english'];
    $physics = $row['physics'];
    $chemistry = $row['chemistry'];
    $biology = $row['biology'];
    $politics = $row['politics'];
    $history = $row['history'];
    $geography = $row['geography'];
}

$scores = [
    'physics' => $physics,
    'chemistry' => $chemistry,
    'biology' => $biology,
    'politics' => $politics,
    'history' => $history,
    'geography' => $geography
];

// 将数组转换为值的数组
$values = array_values($scores);

// 根据值对数组进行排序
rsort($values); // 降序排序

// 取最大的三个值
$topThreeScores = array_slice($values, 0, 3);

// 计算这三个值的总和
$sum = array_sum($topThreeScores);

$sumscore=$chinese+$maths+$english+$sum*0.7;

if ($sumscore>=620){
    echo '<script>window.location.href = "tsinghua.php";</script>';
}
elseif($sumscore>=585){
    echo '<script>window.location.href = "jiaotong.php";</script>';
}
elseif($sumscore>=560){
    echo '<script>window.location.href = "985.php";</script>';
}
elseif($sumscore>=530){
    echo '<script>window.location.href = "211.php";</script>';
}
elseif($sumscore>=510){
    echo '<script>window.location.href = "1.php";</script>';
}
elseif($sumscore<480){
    echo '<script>window.location.href = "nothing.php";</script>';
}
else{
    echo '<script>window.location.href = "2.php";</script>';
}

$_SESSION['chinese'] = $chinese;
$_SESSION['maths'] = $maths;
$_SESSION['english'] = $english;
$_SESSION['physics'] = $physics;
$_SESSION['chemistry'] = $chemistry;
$_SESSION['biology'] = $biology;
$_SESSION['politics'] = $politics;
$_SESSION['history'] = $history;
$_SESSION['geography'] = $geography; 


$sql = "update mytb set chinese=$chinese,maths=$maths,english=$english,physics=$physics,chemistry=$chemistry,biology=$biology,politics=$politics,history=$history,geography=$geography where name1='$name1'";
$result = $con->query($sql);
?>