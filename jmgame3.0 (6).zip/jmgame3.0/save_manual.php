<?php
header('content-type:text/html;charset=utf-8');
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life, day, week, class, music, hospital, coffee_task, coffee, stress, warning, noodle_task, noodle_day, classsleep, homework, diligent, lazy, diligent_king, diligent_god, lazy_king, lazy_god, lovers, lovers_talkleft, lovers_talkright, singer, lastdinner, domitoryhomework, chinese, maths, english, physics, chemistry, biology, politics, history, geography FROM mytb WHERE name1 = '$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}

while($row = $result->fetch_assoc()){
$life = $row['life'];
$day = $row['day'];
$week = $row['week'];
$class = $row['class'];
$music = $row['music'];
$hospital = $row['hospital'];
$coffee_task = $row['coffee_task'];
$coffee = $row['coffee'];
$stress = $row['stress'];
$warning = $row['warning'];
$noodle_task = $row['noodle_task'];
$noodle_day = $row['noodle_day'];
$classsleep = $row['classsleep'];
$homework = $row['homework'];
$diligent = $row['diligent'];
$lazy = $row['lazy'];
$diligent_king = $row['diligent_king'];
$diligent_god = $row['diligent_god'];
$lazy_king = $row['lazy_king'];
$lazy_god = $row['lazy_god'];
$lovers = $row['lovers'];
$lovers_talkleft = $row['lovers_talkleft'];
$lovers_talkright = $row['lovers_talkright'];
$singer = $row['singer'];
$lastdinner = $row['lastdinner'];
$domitoryhomework = $row['domitoryhomework'];
$chinese = $row['chinese'];
$maths = $row['maths'];
$english = $row['english'];
$physics = $row['physics'];
$chemistry = $row['chemistry'];
$biology = $row['biology'];
$politics = $row['politics'];
$history = $row['history'];
$geography = $row['geography'];
}

$sql = "UPDATE mytb SET 
        hospital2 = '".$hospital."',
        life2 = '".$life."',
        day2 = '".$day."',
        week2 = '".$week."',
        class2 = '".$class."',
        music2 = '".$music."',
        coffee_task2 = '".$coffee_task."',
        coffee2 = '".$coffee."',
        stress2 = '".$stress."',
        warning2 = '".$warning."',
        noodle_task2 = '".$noodle_task."',
        noodle_day2 = '".$noodle_day."',
        classsleep2 = '".$classsleep."',
        homework2 = '".$homework."',
        diligent2 = '".$diligent."',
        lazy2 = '".$lazy."',
        diligent_king2 = '".$diligent_king."',
        diligent_god2 = '".$diligent_god."',
        lazy_king2 = '".$lazy_king."',
        lazy_god2 = '".$lazy_god."',
        lovers2 = '".$lovers."',
        lovers_talkleft2 = '".$lovers_talkleft."',
        lovers_talkright2 = '".$lovers_talkright."',
        singer2 = '".$singer."',
        lastdinner2 = '".$lastdinner."',
        domitoryhomework2 = '".$domitoryhomework."',
        chinese2 = '".$chinese."',
        maths2 = '".$maths."',
        english2 = '".$english."',
        physics2 = '".$physics."',
        chemistry2 = '".$chemistry."',
        biology2 = '".$biology."',
        politics2 = '".$politics."',
        history2 = '".$history."',
        geography2 = '".$geography."'
    WHERE name1 = '".$name1."'";
$result = $con->query($sql);
//$sql = "update mytb set hospital2=$hospital,life2=$life,day2=$day,week2=$week,class2=$class,music2=$music,coffee_task2=$coffee_task,coffee2=$coffee,stress2=$stress,warning2=$warning,noodle_task2=$noodle_task,noodle_day2=$noodle_day,classsleep2=$classsleep,homework2=$homework,diligent2=$diligent,lazy2=$lazy,diligent_king2=$diligent_king,diligent_god2=$diligent_god,lazy_king2=$lazy_king,lazy_god2=$lazy_god,lovers2=$lovers,lovers_talkleft2=$lovers_talkleft,lovers_talkright2=$lovers_talkright,singer2=$singer,lastdinner2=$lastdinner,domitoryhomework2=$domitoryhomework,chinese2=$chinese,maths2=$maths,english2=$english,physics2=$physics,chemistry2=$chemistry,biology2=$biology,politics2=$politics,history2=$history,geography2=$geography where name1=$name1";
//$result = $con->query($sql);
if (!$result) {
  // 打印错误信息
  echo "Error: " . $con->error;}

  $_SESSION['class']-=0.5;
 echo '<script>window.location.href = "read_auto.php";</script>';
?>