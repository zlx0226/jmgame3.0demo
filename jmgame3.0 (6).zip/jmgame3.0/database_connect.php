<?php
header('Content-type:text/html;charset=utf8');
$con=mysqli_connect("localhost","root","Zhanglinxuan0226.","mydb");
// 检测连接
if (mysqli_connect_errno())
{
    echo "连接失败: " . mysqli_connect_error();
}
?>