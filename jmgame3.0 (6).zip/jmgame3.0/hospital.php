<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life,hospital,stress,class,day,homework FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $hospital = $row['hospital'];
    $stress = $row['stress'];
    $life=$row['life'];
    $class=$row['class'];
    $day=$row['day'];
    $homework=$row['homework'];
}

$hospital+=1;
$life+=30;
$class+=5;
$day+=1;

if($homework>=100){
    $homework-=100;
}
else{
    $homework=0;
}
$_SESSION['life']=$life;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;
$_SESSION['homework'] = $homework;
$_SESSION['day'] = $day;

$sql = "update mytb set life=$life,class=$class,stress=$stress,homework=$homework,hospital=$hospital,day=$day where name1='$name1'";
$result = $con->query($sql);

?>

<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls autoplay></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<style>
        body {
              background-image: url("ceiling.jpg");
              background-size:100%;
              background-attachment: fixed;
              background-repeat: no-repeat;
            }
        </style>
<link href="css/caught.css" rel="stylesheet" type="text/css" />
<div class = "word_box">
    <p style="font-size: 25px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;生病了，在医务室躺了一上午。生命值+30  </p>
</div> 

<button type="submit" class='button_continue' onclick="window.location.href='newgame_basic.php'">  </button>
</body>
</html>