<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life,class,stress FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $class = $row['class'];
    $stress = $row['stress'];
    $life=$row['life'];
}

$possibility=rand(1,5);
if($possibility<=3){
    $life+=15;
    $_SESSION['word']=6;
}
else{
    $stress+=5;
    $life-=3;
    $_SESSION['word']=5;
}

$class+=1;
$_SESSION['life']=$life;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;

$sql = "update mytb set life=$life,class=$class,stress=$stress where name1='$name1'";
$result = $con->query($sql);

echo '<script>window.location.href = "newgame_basic.php";</script>';
?>