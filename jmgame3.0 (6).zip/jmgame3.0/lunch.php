<?php
require 'database_connect.php';

session_start();
$name1 = $_SESSION['username']; // 确保已经通过 session 获取了用户名

$sql = "SELECT class FROM mytb WHERE name1='$name1'"; // 使用单引号或双引号引起来的变量
$result = $con->query($sql);

// 检查查询是否成功
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;
    exit; // 如果查询失败，退出脚本执行
}

// 假设查询成功，执行循环获取数据
while ($row = $result->fetch_assoc()) {
    $class = $row['class'];
}

// 更新 class 的值
$class += 1;
$_SESSION['class'] = $class; // 将更新后的 class 值保存到 session 中

// 构建更新数据库的 SQL 语句，并执行
$sql = "UPDATE mytb SET class='$class' WHERE name1='$name1'"; // 确保使用参数化查询或合理处理变量以避免 SQL 注入
$result = $con->query($sql);

// 检查更新是否成功
if (!$result) {
    echo "Error updating record: " . $con->error;
    exit; // 如果更新失败，输出错误信息并退出脚本
}
echo '<script>window.location.href = "newgame_basic.php";</script>';
?>