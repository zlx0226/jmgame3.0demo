<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT homework FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $homework = $row['homework'];
}

$homework=100;
$_SESSION['homework'] = $homework;

$sql = "update mytb set homework=$homework where name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}

echo '<script>window.location.href = "read_auto.php";</script>';
?>