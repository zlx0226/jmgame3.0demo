<?php
header('content-type:text/html;charset=utf-8');
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$classnumber=$_SESSION['classnumber'];
$sql = "SELECT coffee,life,class,classsleep,chinese,maths,english,physics,chemistry,biology,politics,history,geography FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $coffee = $row['coffee'];
    $class = $row['class'];
    $chinese = $row['chinese'];
    $maths = $row['maths'];
    $english = $row['english'];
    $physics = $row['physics'];
    $chemistry = $row['chemistry'];
    $biology = $row['biology'];
    $politics = $row['politics'];
    $history = $row['history'];
    $geography = $row['geography'];
    $life=$row['life'];
    $classsleep=$row['classsleep'];
}
if($coffee==0 and $life<=50){
    $possibility=rand(1,2);
    if($possibility==1){
        if($classnumber==1){
            if($chinese<=145){
                $chinese=$chinese+5;
                $_SESSION['word']=3;
            }
            else{
                $chinese=150;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==2){
            if($maths<=145){
                $maths=$maths+5;
                $_SESSION['word']=3;
            }
            else{
                $maths=150;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==3){
            if($english<=145){
                $english=$english+5;
                $_SESSION['word']=3;
            }
            else{
                $english=150;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==4){
            if($physics<=95){
                $physics=$physics+5;
                $_SESSION['word']=3;
            }
            else{
                $physics=100;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==5){
            if($chemistry<=95){
                $chemistry=$chemistry+5;
                $_SESSION['word']=3;
            }
            else{
                $chemistry=100;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==6){
            if($biology<=95){
                $biology=$biology+5;
                $_SESSION['word']=3;
            }
            else{
                $biology=100;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==7){
            if($politics<=95){
                $politics=$politics+5;
                $_SESSION['word']=3;
            }
            else{
                $politics=100;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==8){
            if($history<=95){
                $history=$history+5;
                $_SESSION['word']=3;
            }
            else{
                $history=100;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==9){
            if($geography<=95){
                $geography=$geography+5;
                $_SESSION['word']=3;
            }
            else{
                $geography=100;
                $_SESSION['word']=1;
            }
        }
        $life=$life-5;
    }
    else{
        $_SESSION['word']=2; 
        $classsleep+=1;
        $life=$life-1;
        if($classsleep==3){
            echo '<script>window.location.href = "coffee.php";</script>';
        }
    }
}
else{
    $possibility=rand(1,5);
    if($possibility>2){
        if($classnumber==1){
            if($chinese<=145){
                $chinese=$chinese+5;
                $_SESSION['word']=3;
            }
            else{
                $chinese=150;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==2){
            if($maths<=145){
                $maths=$maths+5;
                $_SESSION['word']=3;
            }
            else{
                $maths=150;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==3){
            if($english<=145){
                $english=$english+5;
                $_SESSION['word']=3;
            }
            else{
                $english=150;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==4){
            if($physics<=95){
                $physics=$physics+5;
                $_SESSION['word']=3;
            }
            else{
                $physics=100;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==5){
            if($chemistry<=95){
                $chemistry=$chemistry+5;
                $_SESSION['word']=3;
            }
            else{
                $chemistry=100;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==6){
            if($biology<=95){
                $biology=$biology+5;
                $_SESSION['word']=3;
            }
            else{
                $biology=100;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==7){
            if($politics<=95){
                $politics=$politics+5;
                $_SESSION['word']=3;
            }
            else{
                $politics=100;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==8){
            if($history<=95){
                $history=$history+5;
                $_SESSION['word']=3;
            }
            else{
                $history=100;
                $_SESSION['word']=1;
            }
        }
        elseif($classnumber==9){
            if($geography<=95){
                $geography=$geography+5;
                $_SESSION['word']=3;
            }
            else{
                $geography=100;
                $_SESSION['word']=1;
            }
        }
        $life=$life-5;
    }
    else{
        $_SESSION['word']=2; 
        $life=$life-1;
        $classsleep+=1;
        if($classsleep==3){
            echo '<script>window.location.href = "coffee.php";</script>';
        }
    }
}
$class+=1;
$_SESSION['life']=$life;
$_SESSION['class']=$class;
$_SESSION['chinese'] = $chinese;
$_SESSION['maths'] = $maths;
$_SESSION['english'] = $english;
$_SESSION['physics'] = $physics;
$_SESSION['chemistry'] = $chemistry;
$_SESSION['biology'] = $biology;
$_SESSION['politics'] = $politics;
$_SESSION['history'] = $history;
$_SESSION['geography'] = $geography; 
$_SESSION['coffee'] = $coffee;
$_SESSION['classsleep'] = $classsleep;

$sql = "update mytb set life=$life,class=$class,classsleep=$classsleep,chinese=$chinese,maths=$maths,english=$english,physics=$physics,chemistry=$chemistry,biology=$biology,politics=$politics,history=$history,geography=$geography where name1='$name1'";
$result = $con->query($sql);

echo '<script>window.location.href = "newgame_basic.php";</script>';
?>