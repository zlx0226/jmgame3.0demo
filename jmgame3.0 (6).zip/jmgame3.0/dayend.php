<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life,hospital,stress,homework,class,day,lazy,diligent_king,lazy_king,diligent_god,lazy_god FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $hospital = $row['hospital'];
    $stress = $row['stress'];
    $homework = $row['homework'];
    $life=$row['life'];
    $class=$row['class'];
    $day=$row['day'];
    $lazy=$row['lazy'];
    $diligent_king=$row['diligent_king'];
    $lazy_king=$row['lazy_king'];
    $diligent_god=$row['diligent_god'];
    $lazy_god=$row['lazy_god'];
}

if($diligent_king==1){
    $life-=3;
    $stress-=3;
}
if($diligent_god==1){
    $life-=7;
    $stress-=5;
}


if($lazy_king==1){
    $life+=3;
    $stress+=3;
}
if($lazy_god==1){
    $life+=5;
    $stress+=7;
}

if($homework<100){
    $_SESSION['word1']=1;
    $lazy+=1;
    $stress+=7;
}
else{
    $_SESSION['word1']=0;
}

$day+=1;

if($stress>=80){
    echo '<script>window.location.href = "jump.php";</script>';
}
elseif($life<=0){
    if($hospital==0){
        echo '<script>window.location.href = "hospital.php";</script>';
    }
    else{
        echo '<script>window.location.href = "die.php";</script>';
    }
}
else{
if($homework>=100){
    $homework-=100;
}
else{
    $homework=0;
}

$class+=1;
$_SESSION['life']=$life;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;
$_SESSION['homework'] = $homework;
$_SESSION['day']=$day;

for ($i=1; $i<=5; $i++) {
if($lazy==5*$i){
    $lazy2=5;
}
}
$_SESSION['lazy'] = $lazy;

$sql = "update mytb set life=$life,class=$class,stress=$stress,homework=$homework,day=$day,lazy=$lazy where name1='$name1'";
$result = $con->query($sql);
if($lazy2==5){
    echo '<script>window.location.href = "lazy2.php";</script>';
}
else{
    echo '<script>window.location.href = "read_auto.php";</script>';
}
}
?>