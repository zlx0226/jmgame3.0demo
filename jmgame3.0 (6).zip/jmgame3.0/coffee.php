<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT coffee_task FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $coffee_task = $row["coffee_task"];
}

$coffee_task=1;
$_SESSION['coffee_task'] = $coffee_task;



$sql = "update mytb set coffee_task=$coffee_task where name1='$name1'";
$result = $con->query($sql);
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls ></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<style>
        body {
              background-image: url("classroom.jpg");
              background-size:100%;
              background-attachment: fixed;
              background-repeat: no-repeat;
            }
        </style>
<link href="css/caught.css" rel="stylesheet" type="text/css" />
<div class = "word_box">
    <div class="name_box">
        <p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p>
    </div>
    <p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;啊呀！怎么上课又睡着了？怎么才能保持清醒呢？ </p>
</div> 

<button type="submit" class='button_continue' onclick="c1()">  </button>
<script>

function hideElementsByClass(className)
 {
  var elements = document.querySelectorAll('.' + className);
  elements.forEach(function(element) {
    element.style.display = 'none';
  });
}

function c1(){
    hideElementsByClass("words");
    document.body.innerHTML += '<img src="student_wangguihua.png" width=43% height=97% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;王桂花 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;嘿！你是不是昨天晚上又偷偷卷作业了？ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c2()">  </button>';
   }
function c2(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;我哪有！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c3()">  </button>';
   }
 function c3(){
    hideElementsByClass("words");
    document.body.innerHTML += '<img src="student_juangou_happy.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;卷王 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;呵呵！年轻人，你的卷狗之道缺乏基础知识啊！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c4()">  </button>';
 }
 function c4(){
  hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;啊？卷王大师，还请多多指教！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c5()">  </button>';
 }
 function c5(){
    hideElementsByClass("words");
    document.body.innerHTML += '<img src="student_juangou_happy.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;卷王 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;贝纳颂，你可知道？每周一排贝纳颂，是每一代卷王的起点！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c6()">  </button>';
 }
 function c6(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;大师！受教了！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c7()">  </button>';
 }
 function c7(){
    hideElementsByClass("words");
    document.body.innerHTML += '<div class = "word_box"><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;任务：在中午抢购一排贝纳颂（可在菜单—任务与成就中查看） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="window.location.href=\'read_auto.php\'">  </button>';
 }
</script>

</body>
</html>
