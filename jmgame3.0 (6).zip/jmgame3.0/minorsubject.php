<?php
require 'database_connect.php';

session_start();
$name1 = $_SESSION['username'];
$sql = "SELECT class, stress, music FROM mytb WHERE name1 = '$name1'";
$result = $con->query($sql);

if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;
    exit; // 退出脚本，避免进一步的错误
}

while ($row = $result->fetch_assoc()) {
    $class = $row['class'];
    $stress = $row['stress'];
    $music = $row['music'];
}

if($_SESSION['classnumber']==10){
    $music+=1;
}

$class+=1;
$stress-=3;
$_SESSION['word']=7;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;
$_SESSION['music']=$music;

$sql = "update mytb set music=$music,class=$class,stress=$stress where name1='$name1'";
$result = $con->query($sql);

echo '<script>window.location.href = "read_auto.php";</script>';
?>