<?php
session_start();
if($_SESSION['specialname']==1 or $_SESSION['specialname']==2){
    echo '<script>window.location.href = "classroom.php";</script>';
}
else{
$possibility=rand(1,2);
if($possibility==1){
    echo '<script>window.location.href = "classroom.php";</script>';
}
else{
    echo '<script>window.location.href = "caught.php";</script>';
}
}
?>