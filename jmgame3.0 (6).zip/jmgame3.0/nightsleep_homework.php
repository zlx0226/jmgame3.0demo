<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life,class,stress,homework,coffee FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $class = $row['class'];
    $stress = $row['stress'];
    $homework = $row['homework'];
    $life=$row['life'];
    $coffee=$row['coffee'];
}

$homework+=rand(30,40);
if($homework<=100){
    $_SESSION['word']=11;
    if($coffee==1){
        echo '<script>window.location.href = "lastdinner1.php";</script>';
    }
    else{
        echo '<script>window.location.href = "dayend.php";</script>';
    }
}
else{
    $_SESSION['homework']=$homework;
    $_SESSION['word']=11;
    echo '<script>window.location.href = "homework_skip2.php";</script>';
}


$life-=30;
$_SESSION['life']=$life;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;
$_SESSION['homework'] = $homework;

$sql = "update mytb set life=$life,class=$class,stress=$stress,homework=$homework where name1='$name1'";
$result = $con->query($sql);

?>