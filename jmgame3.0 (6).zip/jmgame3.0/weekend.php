<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life,hospital,stress,homework,class,day,week FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $hospital = $row['hospital'];
    $stress = $row['stress'];
    $homework = $row['homework'];
    $life=$row['life'];
    $class=$row['class'];
    $day=$row['day'];
    $week=$row['week'];
}
if($week<3){
$day+=1;
$class=1;
$week+=1;

if($stress>=80){
    echo '<script>window.location.href = "jump.php";</script>';
}
elseif($life<=0){
    if($hospital==0){
        echo '<script>window.location.href = "hospital.php";</script>';
    }
    else{
        echo '<script>window.location.href = "die.php";</script>';
    }
}
else{
if($homework>=100){
    $homework-=100;
}
else{
    $homework=0;
}
$_SESSION['life']=$life;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;
$_SESSION['homework'] = $homework;
$_SESSION['day']=$day;

$sql = "update mytb set life=$life,class=$class,stress=$stress,homework=$homework,day=$day where name1='$name1'";
$result = $con->query($sql);

    echo '<script>window.location.href = "read_auto.php";</script>';
}
$_SESSION['week']=$week;

$sql = "update mytb set week=$week where name1='$name1'";
$result = $con->query($sql);
}
else{
    echo '<script>window.location.href = "ending.php";</script>';
}
?>