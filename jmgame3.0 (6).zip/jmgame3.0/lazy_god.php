<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT lazy_god,lazy_god_achieve FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $lazy_god = $row["lazy_god"];
    $lazy_god_achieve = $row["lazy_god_achieve"];
}

$lazy_god=1;
$_SESSION['lazy_god'] = $lazy_god;
$lazy_god_achieve=1;
$_SESSION['lazy_god_achieve'] = $lazy_god_achieve;


$sql = "update mytb set lazy_god=$lazy_god, lazy_god_achieve=$lazy_god_achieve where name1='$name1'";
$result = $con->query($sql);
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls ></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<style>
        body {
              background-image: url("classroom.jpg");
              background-size:100%;
              background-attachment: fixed;
              background-repeat: no-repeat;
            }
        </style>
<link href="css/caught.css" rel="stylesheet" type="text/css" />
<img src="teacher_angry.png" width=43%  class="picture"/>
<button type="submit" class='button_continue' onclick="c1()">  </button>
<script>

  var name1= <?php echo $_SESSION['username'];?>;
document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;z-index: 1;"> &nbsp;&nbsp;&nbsp;&nbsp;老师 </p></div><p class="words" style="font-size: 35px; color:white;z-index: -1;"> &nbsp;&nbsp;&nbsp;&nbsp;'+name1+' ，你的作业呢？再交不出来，你也不要听课了，去办公室补好了再回来！</p></div> '


function hideElementsByClass(className)
 {
  var elements = document.querySelectorAll('.' + className);
  elements.forEach(function(element) {
    element.style.display = 'none';
  });
}

function c1(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;……（撕开面包的包装袋） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c2()">  </button>';
   }
function c2(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
     document.body.innerHTML += '<img src="teacher_angry.png" width=43%  class="picture"/>'
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;老师 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;你听见没有？！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c3()">  </button>';
   }
 function c3(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;……（取出一片面包） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c4()">  </button>';
   }
 function c4(){
  hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="teacher_angry.png" width=43%  class="picture"/>'
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;老师 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;所以你的作业呢？ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c5()">  </button>';
 }
 function c5(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;……（打开金枪鱼酱的包装） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c6()">  </button>';
   }
 function c6(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="teacher_angry.png" width=43%  class="picture"/>'
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;老师 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;你每个周五都留下来补作业！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c7()">  </button>';
 }
 function c7(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;……（在面包上涂上金枪鱼酱） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c8()">  </button>';
   }
 function c8(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="student_limeili.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;李美丽 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp 你是真的不写啊？ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c9()">  </button>';
 }
 function c9(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;……（咬一口面包） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c10()">  </button>';
   }
function c10(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    document.body.innerHTML += '<img src="student_zhangzhengzhi.png" width=40% height=100% class="picture"/>';
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;张正直 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp 我劝你呢，最好还是写一写。 </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c11()">  </button>';
 }
 function c11(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><div class="name_box"><p class="words" style="font-size: 20px; color:white; position: absolute;top:-40%;"> &nbsp;&nbsp;&nbsp;&nbsp;你 </p></div><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;&nbsp;&nbsp;金枪鱼面包真好吃！ </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="c12()">  </button>';
   }
 function c12(){
    hideElementsByClass("words");
    hideElementsByClass("picture");
    hideElementsByClass("name_box");
    document.body.innerHTML += '<div class = "word_box"><p class="words" style="font-size: 35px; color:white;"> &nbsp;&nbsp;解锁成就“躺平”！（每天压力+7，生命+5）（请勿模仿！） </p></div> ';
   document.body.innerHTML += '<button type="submit" class="button_continue" onclick="window.location.href=\'read_auto.php\'">  </button>';
 }


</script>

</body>
</html>