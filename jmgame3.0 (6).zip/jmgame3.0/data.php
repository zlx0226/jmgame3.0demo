<?php
$servername = "localhost";
$username = "root";
$password = "Zhanglinxuan0226.";
$dbname = "mydb";
 //连接
$conn = new mysqli($servername, $username, $password);
// 检测连接
if ($conn->connect_error) {
    die("连接失败: " . $conn->connect_error);
} 

$sql = "INSERT INTO MyGuests (username, userpassword)
VALUES ('Jm', 'pleaserunit')";
 
if ($conn->query($sql) === TRUE) {
    echo "新记录插入成功";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
    
 
$conn->close();
?>