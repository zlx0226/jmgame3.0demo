<?php
header('content-type:text/html;charset=utf-8');
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life, day, week, class, music, coffee_task, coffee, stress, warning, noodle_task, noodle_day, classsleep, homework, diligent, lazy, diligent_king, diligent_god, lazy_king, lazy_god, lovers, lovers_talkleft, lovers_talkright, singer, lastdinner, domitoryhomework, chinese, maths, english, physics, chemistry, biology, politics, history, geography
 FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
// 使用预处理语句来防止SQL注入
$stmt = $con->prepare($sql);
$stmt->bind_param("s", $name1); // "s" 表示绑定的参数是字符串类型

// 执行查询
$stmt->execute();
$result = $stmt->get_result();

// 检查结果并赋值给SESSION变量
if ($result->num_rows > 0) {
    // 获取第一条记录
    $row = $result->fetch_assoc();
    
    // 将查询结果赋值给SESSION变量
    $_SESSION['life'] = $row['life'];
    $_SESSION['day'] = $row['day'];
    $_SESSION['week'] = $row['week'];
    $_SESSION['class'] = $row['class'];
    $_SESSION['music'] = $row['music'];
    $_SESSION['coffee_task'] = $row['coffee_task'];
    $_SESSION['coffee'] = $row['coffee'];
    $_SESSION['stress'] = $row['stress'];
    $_SESSION['warning'] = $row['warning'];
    $_SESSION['noodle_task'] = $row['noodle_task'];
    $_SESSION['noodle_day'] = $row['noodle_day'];
    $_SESSION['classsleep'] = $row['classsleep'];
    $_SESSION['homework'] = $row['homework'];
    $_SESSION['diligent'] = $row['diligent'];
    $_SESSION['lazy'] = $row['lazy'];
    $_SESSION['diligent_king'] = $row['diligent_king'];
    $_SESSION['diligent_god'] = $row['diligent_god'];
    $_SESSION['lazy_king'] = $row['lazy_king'];
    $_SESSION['lazy_god'] = $row['lazy_god'];
    $_SESSION['lovers'] = $row['lovers'];
    $_SESSION['lovers_talkleft'] = $row['lovers_talkleft'];
    $_SESSION['lovers_talkright'] = $row['lovers_talkright'];
    $_SESSION['singer'] = $row['singer'];
    $_SESSION['lastdinner'] = $row['lastdinner'];
    $_SESSION['domitoryhomework'] = $row['domitoryhomework'];
    $_SESSION['chinese'] = $row['chinese'];
    $_SESSION['maths'] = $row['maths'];
    $_SESSION['english'] = $row['english'];
    $_SESSION['physics'] = $row['physics'];
    $_SESSION['chemistry'] = $row['chemistry'];
    $_SESSION['biology'] = $row['biology'];
    $_SESSION['politics'] = $row['politics'];
    $_SESSION['history'] = $row['history'];
    $_SESSION['geography'] = $row['geography'];
}

// 关闭预处理语句
$stmt->close();


echo '<script>window.location.href = "newgame_basic.php";</script>';
?>