<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life,class,homework,coffee FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $class = $row['class'];
    $homework = $row['homework'];
    $life=$row['life'];
    $coffee=$row['coffee'];
}

$homework=100;
$_SESSION['life']=$life;
$_SESSION['class']=$class;
$_SESSION['homework'] = $homework;

$sql = "update mytb set life=$life,class=$class,homework=$homework where name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}

//if($coffee==1){
  //  echo '<script>window.location.href = "lastdinner1.php";</script>';
//}
//else{
    echo '<script>window.location.href = "dayend.php";</script>';
//}
?>