<?php
$servername = "localhost";
$username = "root";
$password = "Zhanglinxuan0226.";
$dbname = "mydb";

$con=mysqli_connect("localhost","root","Zhanglinxuan0226.","mydb");
// 检测连接
if (mysqli_connect_errno())
{
    echo "连接失败: " . mysqli_connect_error();
}


$name1 =$_POST['signup_username'];
$userpassword =$_POST['signup_password'];

$select="select name1 from mytb where name1='$name1'";
$result = mysqli_query($con,$select);

$row=mysqli_num_rows($result);

if (!$row)
{ $sql = "INSERT INTO mytb (name1, userpassword) VALUES ('$name1', '$userpassword')";
  $result = $con->query($sql);
    echo "注册成功";
    echo "<button type='submit' onclick='window.location.href=\"login.html\"'> 返回登录 </button>";
}
else{
    echo "用户名重复，请换一个！";
    echo "<br>";
    echo "<button type='submit' onclick='window.location.href=\"signup.html\"'> 返回 </button>";}
?>