<?php  
// 数据库配置  
$servername = "localhost:3306";  // 注意：通常 localhost 后不需要跟端口号，除非你的 MySQL 服务不是运行在标准端口 3306 上  
// 如果你需要指定端口，应该在连接时通过其他方式指定，比如使用 DSN 字符串（对于 PDO）  
// 或者在 mysqli 中使用 mysqli_real_connect 函数时指定  
$username = "admin";  
$password = "123456";  
$dbname = "bettercode";  
  
// 创建连接  
$conn = new mysqli($servername, $username, $password, $dbname);  
  
// 检查连接  
if ($conn->connect_error) {  
    die("连接失败: " . $conn->connect_error);  
}  
  
// 获取表单数据  
$username = $_POST['username'] ?? '';  // 使用空合并运算符提供默认值  
$password = $_POST['password'] ?? '';  
  
// 检查用户名是否为空  
if (empty($username) || empty($password)) {  
    die("用户名和密码不能为空！");  
}  
  
// 准备 SQL 语句来检查用户名是否已存在  
$checkUsernameSql = "SELECT name FROM user WHERE name = ?";  
$stmt = $conn->prepare($checkUsernameSql);  
$stmt->bind_param("s", $username);  
$stmt->execute();  
$result = $stmt->get_result();  
  
// 检查是否有行返回，即用户名是否已存在  
if ($result->num_rows > 0) {  
    die("已经存在此名称");  
}  
  
// 加密密码  
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);  
  
// 准备 SQL 语句来插入新用户  
$sql = "INSERT INTO user (name, password) VALUES (?, ?)";  
$stmt = $conn->prepare($sql);  
$stmt->bind_param("ss", $username, $hashedPassword);  
  
// 执行 SQL 语句  
if ($stmt->execute() === TRUE) {  
    echo "注册成功";  
} else {  
    echo "Error: " . $stmt->error;  
}  
  
$stmt->close();  
$conn->close();  
?>