<?php  
$servername = "localhost";  
$username = "admin";  
$password = "123456";  
$dbname = "bettercode";  
  
// 创建连接  
$conn = new mysqli($servername, $username, $password, $dbname);  
  
// 检查连接  
if ($conn->connect_error) {  
    die("Connection failed: " . $conn->connect_error);  
}

$username = $conn->real_escape_string($_POST['username']);  
$password = $_POST['password'];  
  
$sql = "SELECT password FROM user WHERE name = ?";  
$stmt = $conn->prepare($sql);  
$stmt->bind_param("s", $username);  
$stmt->execute();  
$result = $stmt->get_result();  
  
if ($result->num_rows == 1) {  
    // 取出存储的哈希值  
    $row = $result->fetch_assoc();  
    $storedHash = $row['password'];  
  
    // 验证密码  
    if (password_verify($password, $storedHash)) {  
        echo "登录成功";  
    } else {  
        echo "密码错误";  
    }  
} else {  
    echo "用户不存在";  
}  
  
$stmt->close();  
$conn->close();  
?>