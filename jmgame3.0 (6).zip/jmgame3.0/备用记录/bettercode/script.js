function registerUser() {  
    const username = document.getElementById('username').value;  
    const password = document.getElementById('password').value;  
  
    // 发送AJAX请求到服务器  
    const xhr = new XMLHttpRequest();  
    xhr.open('POST', 'register.php', true);  
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');  
    xhr.onreadystatechange = function () {  
        if (xhr.readyState === 4 && xhr.status === 200) {  
            document.getElementById('message').textContent = xhr.responseText;  
        }  
    };  
    xhr.send(`username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`);  
}  

function loginUser() {  
    const username = document.getElementById('username').value;  
    const password = document.getElementById('password').value;  
  
    // 发送AJAX请求到服务器  
    const xhr = new XMLHttpRequest();  
    xhr.open('POST', 'login.php', true);  
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');  
    xhr.onreadystatechange = function () {  
        if (xhr.readyState === 4 && xhr.status === 200) {  
            document.getElementById('message').textContent = xhr.responseText;  
        }  
    };  
    xhr.send(`username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`);  
}  