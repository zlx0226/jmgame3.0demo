<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body >
<audio id="music" src="music.m4a" loop="loop" hidden="true" controls autoplay></audio>

<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }  
 
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<style>
 body {
      background-image: url("building_background2.jpg");
      background-size: cover;
      background-repeat: no-repeat;
    }
.lesson_box {
            position: absolute;
            top: 5%;
            left: 5%;
            width: 60%;
            height: 75%;
            border: 1px solid hsla(0, 0%, 44%, 0.282);
            background-color: #ffffff76;
            border-radius: 20px;
        }
.health_box {
            position: absolute;
            top: 5%;
            right: 5%;
            width: 25%;
            height: 65%;
            border: 1px solid #71717148;
            background-color: #ffffff76;
            border-radius: 20px;
        }
.health_box2 {
            position: absolute;
            top: 5%;
            right: 5%;
            width: 25%;
            height: 65%;
            border: 1px ;
            border-radius: 20px;
        }
.lesson_box2 {
            position: absolute;
            top: 5%;
            left: 5%;
            width: 60%;
            height: 75%;
            border: 1px;
            border-radius: 20px;
        }
</style>
<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" />
<div class = "lesson_box">
    <!--用于显示课程表的区块-->
    <img src="classes.png" width=100% height=80% class="classes"/>
    <p style="font-size: 40px; position:absolute; left:20%;"> 距离期中考还有：<?php 
    session_start();
    echo 28-$_SESSION['week']*7-$_SESSION['day']; ?> 天 </p>
</div>
<div class = "health_box">
    <!--用于显示健康等数据-->
    <p style="font-size: 32px; position:absolute; left:7%;"> 生命值：<?php session_start();
    echo $_SESSION['life']; ?> </p>
    <p style="font-size: 32px; position:absolute; left:7%; top:10%;"> 压力：<?php session_start();
    echo $_SESSION['stress']; ?> </p>
    <p style="font-size: 28px; position:absolute; left:10%; top:22%;"> 语文：<?php session_start();
    echo $_SESSION['chinese']; ?> </p>
    <p style="font-size: 28px; position:absolute; left:50%; top:22%;"> 数学：<?php session_start();
    echo $_SESSION['maths']; ?> </p>
    <p style="font-size: 28px; position:absolute; left:10%; top:30%;"> 英语：<?php session_start();
    echo $_SESSION['english']; ?> </p>
    <p style="font-size: 28px; position:absolute; left:50%; top:30%;"> 物理：<?php session_start();
    echo $_SESSION['physics']; ?> </p>
    <p style="font-size: 28px; position:absolute; left:10%; top:38%;"> 化学：<?php session_start();
    echo $_SESSION['chemistry']; ?> </p>
    <p style="font-size: 28px; position:absolute; left:50%; top:38%;"> 政治：<?php session_start();
    echo $_SESSION['politics']; ?> </p>
    <p style="font-size: 28px; position:absolute; left:10%; top:46%;"> 历史：<?php session_start();
    echo $_SESSION['history']; ?> </p>
    <p style="font-size: 28px; position:absolute; left:50%; top:46%;"> 生物：<?php session_start();
    echo $_SESSION['biology']; ?> </p>
    <p style="font-size: 28px; position:absolute; left:10%; top:54%;"> 地理：<?php session_start();
    echo $_SESSION['geography']; ?> </p>
    <p style="font-size: 33px; position:absolute; left:7%; top:62%;"> 作业完成情况：<?php session_start();
    echo $_SESSION['homework']; ?> /100 </p>
</div>
<link href="css/back_to_frontpage2.css" rel="stylesheet" type="text/css" />
<button type="submit" class='back_to_frontpage2' onclick="window.location.href='main.php'"> 返  回  标  题 </button>
<link href="css/button_system.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button_system' onclick="window.location.href='system.php'"> . </button>
<link href="css/button_save.css" rel="stylesheet" type="text/css" />
<button type="submit" class='button_save' onclick="window.location.href='save_manual.php'"> 存  档 </button>

<?php
function word(){
  if($_SESSION['word']==1){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 大佬，别学了，你已经满分了！ </p>
    </div>';
  }
  elseif($_SESSION['word']==0){
    echo '<div class = "health_box2">
      <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> . </p>
      </div>';
  }
  elseif($_SESSION['word']==2){
      echo '<div class = "health_box2">
      <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 一不小心睡着了……生命值-1 </p>
      </div>';
  }
  elseif($_SESSION['word']==3){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 好好学习，天天向上。分数+5，生命值-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==4){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 一节课能写这么多。作业完成度增加，生命值-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==5){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 啊呀，被老师逮住了。压力+5，生命值-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==6){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 睡得真爽。生命值+15 </p>
    </div>';
  }
  elseif($_SESSION['word']==7){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 偶尔上节副科真是太开心了！压力-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==8){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 啊呀，旷课被抓了……压力+30，处分+1 </p>
    </div>';
  }
  elseif($_SESSION['word']==9){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 逛校园使人快乐。压力-2 </p>
    </div>';
  }
  elseif($_SESSION['word']==10){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 聊天使人快乐。压力-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==11){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 朋友，你见过jiaomin凌晨5点的太阳吗！生命值-30 </p>
    </div>';
  }
  elseif($_SESSION['word']==12){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 聊天使人快乐。压力-6，生命值+10 </p>
    </div>';
  }
  elseif($_SESSION['word']==13){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 一夜好眠。生命+20 </p>
    </div>';
  }
  elseif($_SESSION['word']==15){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 考试好累。生命-3 </p>
    </div>';
  }
  elseif($_SESSION['word']==16){
    echo '<div class = "health_box2">
    <p style="font-size: 20px; position:absolute; left:7%;right:7%; top:82%;color:blue;"> 考试睡觉，主打一个自信。 </p>
    </div>';
  }
}

function maincourse(){
  echo '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" />
  <button type="submit" class="serious" onclick="window.location.href=\'maincourse.php\'"> 认真上课 </button>;
  <button type="submit" class="homework" onclick="window.location.href=\'maincourse_homework.php\'"> 卷作业 </button>;
  <button type="submit" class="sleep" onclick="window.location.href=\'maincourse_sleep.php\'"> 睡觉 </button>';
  session_start();
  $_SESSION['class']+=0.5;
  word();
}

function minorsubject(){
  echo '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" />
  <button type="submit" class="serious" onclick="window.location.href=\'minorsubject.php\'"> 认真上课 </button>;
  <button type="submit" class="homework" onclick="window.location.href=\'minorsubject_homework.php\'"> 卷作业 </button>;
  <button type="submit" class="sleep" onclick="window.location.href=\'minorsubject_sleep.php\'"> 睡觉 </button>';
  session_start();
  $_SESSION['class']+=0.5;
  word();
}

function pe(){
  echo '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" />
  <button type="submit" class="serious" onclick="window.location.href=\'pe_truancy.php\'"> 旷课 </button>;
  <button type="submit" class="homework" onclick="window.location.href=\'pe_stroll.php\'"> 闲逛 </button>;
  <button type="submit" class="sleep" onclick="window.location.href=\'minorsubject.php\'"> 运动 </button>';
  session_start();
  $_SESSION['class']+=0.5;
  word();
}

function nightstudy(){
  echo '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" />
  <button type="submit" class="serious" onclick="window.location.href=\'nightstudy_homework.php\'"> 卷作业 </button>;
  <button type="submit" class="homework" onclick="window.location.href=\'maincourse_sleep.php\'"> 睡觉 </button>;
  <button type="submit" class="sleep" onclick="window.location.href=\'nightstudy_chat.php\'"> 聊天 </button>';
  session_start();
  $_SESSION['class']+=0.5;
  word();
}

function nightsleep(){
  echo '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" />
  <button type="submit" class="serious" onclick="window.location.href=\'nightsleep_homework.php\'"> 卷作业 </button>;
  <button type="submit" class="homework" onclick="window.location.href=\'nightsleep_sleep.php\'"> 睡觉 </button>;
  <button type="submit" class="sleep" onclick="window.location.href=\'nightsleep_chat.php\'"> 聊天 </button>';
  session_start();
  $_SESSION['class']+=0.5;
  word();
}

function exam(){
  echo '<link href="css/newgame_basic.css" rel="stylesheet" type="text/css" />
  <button type="submit" class="serious_exam" onclick="window.location.href=\'exam_serious.php\'"> 认真考试 </button>;
  <button type="submit" class="lazy_exam" onclick="window.location.href=\'exam_lazy.php\'"> 敷衍了事 </button>';
  session_start();
  $_SESSION['class']+=0.5;
  word();
}

function weekend(){
  echo '<script>window.location.href = "weekend.php";</script>';
}

//for($i=1;$i<=8;$i++){
 // for($m=1;$m<=58;$m++){
    if($_SESSION['day']==1){
      if($_SESSION['class']==1){
        $_SESSION['classnumber']=1;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:28%;"/>
        </div>';
        if($_SESSION['word1']==2){
          echo'<p style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;"> 考试考了不及格。压力+5 </p>';
        }
      }
      elseif($_SESSION['class']==2){
        $_SESSION['classnumber']=3;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:34.1%;"/>
        </div>';
      }
      elseif($_SESSION['class']==3){
        $_SESSION['classnumber']=2;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:40.2%;"/>
        </div>';
      }
      elseif($_SESSION['class']==4){
        $_SESSION['classnumber']=5;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:46.3%;"/>
        </div>';
      }
      elseif($_SESSION['class']==5){
        $_SESSION['classnumber']=4;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:52.4%;"/>
        </div>';
      }
      elseif($_SESSION['class']==6){
        if($_SESSION['coffee_task']==1){
          echo '<script>window.location.href = "canteen_coffee.php";</script>';
        }
        else{
          echo '<script>window.location.href = "lunch.php";</script>';
        }
      }
      elseif($_SESSION['class']==7){
        minorsubject();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:58.9%;"/>
        </div>';
      }
      elseif($_SESSION['class']==8){
        $_SESSION['classnumber']=8;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:65.7%;"/>
        </div>';
      }
      elseif($_SESSION['class']==9){
        $_SESSION['classnumber']=9;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:72.3%;"/>
        </div>';
      }
      elseif($_SESSION['class']==10){
        pe();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:78.9%;"/>
        </div>';
      }
      elseif($_SESSION['class']==11){
        nightstudy();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:85.9%;"/>
        </div>';
      }
      elseif($_SESSION['class']==12){
        nightsleep();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:92.8%;"/>
        </div>';
      }
    }
    elseif($_SESSION['day']==2){
      if($_SESSION['class']==1){
        $_SESSION['classnumber']=3;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:28%;left:17%;"/>
        </div>';
        if($_SESSION['word1']==1){
          echo'<p style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;"> 作业没写完。压力+7 </p>';
        }
      }
      elseif($_SESSION['class']==2){
        $_SESSION['classnumber']=8;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:34.1%;left:17%;"/>
        </div>';
      }
      elseif($_SESSION['class']==3){
        $_SESSION['classnumber']=4;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:40.2%;left:17%;"/>
        </div>';
      }
      elseif($_SESSION['class']==4){
        $_SESSION['classnumber']=9;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:46.3%;left:17%;"/>
        </div>';
      }
      elseif($_SESSION['class']==5){
        $_SESSION['classnumber']=7;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:52.4%;left:17%;"/>
        </div>';
      }
      elseif($_SESSION['class']==6){
        if($_SESSION['coffee_task']==1){
          echo '<script>window.location.href = "canteen_coffee.php";</script>';
        }
        else{
          echo '<script>window.location.href = "lunch.php";</script>';
        }
      }
      elseif($_SESSION['class']==7){
        $_SESSION['classnumber']=2;
        exam();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:58.9%;left:17%;"/>
        </div>';
      }
      elseif($_SESSION['class']==8){
        $_SESSION['classnumber']=6;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:65.7%;left:17%;"/>
        </div>';
        if($_SESSION['word1']==2){
          echo'<p style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;"> 考试考了不及格。压力+5 </p>';
        }
      }
      elseif($_SESSION['class']==9){
        $_SESSION['classnumber']=1;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:72.3%;left:17%;"/>
        </div>';
      }
      elseif($_SESSION['class']==10){
        $_SESSION['classnumber']=5;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:78.9%;left:17%;"/>
        </div>';
      }
      elseif($_SESSION['class']==11){
        nightstudy();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:85.9%;left:17%;"/>
        </div>';
      }
      elseif($_SESSION['class']==12){
        nightsleep();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:92.8%;left:17%;"/>
        </div>';
      }
    }
    elseif($_SESSION['day']==3){
      if($_SESSION['class']==1){
        $_SESSION['classnumber']=2;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:28%;left:34%;"/>
        </div>';
        if($_SESSION['word1']==1){
          echo'<p style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;"> 作业没写完。压力+7 </p>';
        }
      }
      elseif($_SESSION['class']==2){
        $_SESSION['classnumber']=4;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:34.1%;left:34%;"/>
        </div>';
      }
      elseif($_SESSION['class']==3){
        $_SESSION['classnumber']=8;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:40.2%;left:34%;"/>
        </div>';
      }
      elseif($_SESSION['class']==4){
        $_SESSION['classnumber']=1;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:46.3%;left:34%;"/>
        </div>';
      }
      elseif($_SESSION['class']==5){
        $_SESSION['classnumber']=7;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:52.4%;left:34%;"/>
        </div>';
      }
      elseif($_SESSION['class']==6){
        if($_SESSION['coffee_task']==1){
          echo '<script>window.location.href = "canteen_coffee.php";</script>';
        }
        else{
          echo '<script>window.location.href = "lunch.php";</script>';
        }
      }
      elseif($_SESSION['class']==7){
        $_SESSION['classnumber']=10;
        minorsubject();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:58.9%;left:34%;"/>
        </div>';
      }
      elseif($_SESSION['class']==8){
        minorsubject();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:65.7%;left:34%;"/>
        </div>';
      }
      elseif($_SESSION['class']==9){
        $_SESSION['classnumber']=3;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:72.3%;left:34%;"/>
        </div>';
      }
      elseif($_SESSION['class']==10){
        $_SESSION['classnumber']=6;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:78.9%;left:34%;"/>
        </div>';
      }
      elseif($_SESSION['class']==11){
        nightstudy();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:85.9%;left:34%;"/>
        </div>';
      }
      elseif($_SESSION['class']==12){
        nightsleep();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:92.8%;left:34%;"/>
        </div>';
      }
    }
    elseif($_SESSION['day']==4){
      if($_SESSION['class']==1){
        $_SESSION['classnumber']=1;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:28%;left:51%;"/>
        </div>';
        if($_SESSION['word1']==1){
          echo'<p style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;"> 作业没写完。压力+7 </p>';
        }
      }
      elseif($_SESSION['class']==2){
        $_SESSION['classnumber']=5;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:34.1%;left:51%;"/>
        </div>';
      }
      elseif($_SESSION['class']==3){
        $_SESSION['classnumber']=9;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:40.2%;left:51%;"/>
        </div>';
      }
      elseif($_SESSION['class']==4){
        $_SESSION['classnumber']=7;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:46.3%;left:51%;"/>
        </div>';
      }
      elseif($_SESSION['class']==5){
        $_SESSION['classnumber']=2;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:52.4%;left:51%;"/>
        </div>';
      }
      elseif($_SESSION['class']==6){
        if($_SESSION['coffee_task']==1){
          echo '<script>window.location.href = "canteen_coffee.php";</script>';
        }
        else{
          echo '<script>window.location.href = "lunch.php";</script>';
        }
      }
      elseif($_SESSION['class']==7){
        $_SESSION['classnumber']=6;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:58.9%;left:51%;"/>
        </div>';
      }
      elseif($_SESSION['class']==8){
        pe();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:65.7%;left:51%;"/>
        </div>';
      }
      elseif($_SESSION['class']==9){
        $_SESSION['classnumber']=3;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:72.3%;left:51%;"/>
        </div>';
      }
      elseif($_SESSION['class']==10){
        minorsubject();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:78.9%;left:51%;"/>
        </div>';
      }
      elseif($_SESSION['class']==11){
        nightstudy();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:85.9%;left:51%;"/>
        </div>';
      }
      elseif($_SESSION['class']==12){
        nightsleep();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:92.8%;left:51%;"/>
        </div>';
      }
    }
    elseif($_SESSION['day']==5){
      if($_SESSION['class']==1){
        $_SESSION['classnumber']=2;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:28%;left:67%;"/>
        </div>';
        if($_SESSION['word1']==1){
          echo'<p style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;"> 作业没写完。压力+7 </p>';
        }
      }
      elseif($_SESSION['class']==2){
        $_SESSION['classnumber']=4;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:34.1%;left:67%;"/>
        </div>';
      }
      elseif($_SESSION['class']==3){
        $_SESSION['classnumber']=7;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:40.2%;left:67%;"/>
        </div>';
      }
      elseif($_SESSION['class']==4){
        $_SESSION['classnumber']=8;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:46.3%;left:67%;"/>
        </div>';
      }
      elseif($_SESSION['class']==5){
        $_SESSION['classnumber']=5;
        maincourse();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:52.4%;left:67%;"/>
        </div>';
      }
      elseif($_SESSION['class']==6){
        if($_SESSION['coffee_task']==1){
          echo '<script>window.location.href = "canteen_coffee.php";</script>';
        }
        else{
          echo '<script>window.location.href = "lunch.php";</script>';
        }
      }
      elseif($_SESSION['class']==7){
        minorsubject();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:58.9%;left:67%;"/>
        </div>';
      }
      elseif($_SESSION['class']==8){
        minorsubject();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:65.7%;left:67%;"/>
        </div>';
      }
      elseif($_SESSION['class']==9){
        $_SESSION['classnumber']=2;
        exam();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:85.9%;right:0%;"/>
        </div>';
      }
      elseif($_SESSION['class']==10){
        $_SESSION['classnumber']=3;
        exam();
        echo '<div class = "lesson_box2">
        <img src="square.png" width=17% height=6.5% style="position:absolute;top:92.8%;right:0%;"/>
        </div>';
        if($_SESSION['word1']==2){
          echo'<p style="font-size: 20px; position:absolute;right:3%;width:10%; top:10%;color:blue;"> 考试考了不及格。压力+5 </p>';
        }
      }
      elseif($_SESSION['class']==11){
      weekend();
      }
    }
 // }
//}
?>

</body>
<script>
</script>
</html>