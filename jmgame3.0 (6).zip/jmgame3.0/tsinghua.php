<?php
header('content-type:text/html;charset=utf-8');
require 'database_connect.php';
$life=rand(80,100);
$day=1;
$class=1;
$chinese=rand(60,75);
$maths=rand(60,75);
$english=rand(60,75);
$physics=rand(20,30);
$chemistry=rand(20,30);
$biology=rand(50,70);
$politics=rand(20,30);
$history=rand(20,30);
$geography=rand(50,70);
$music=0;
$coffee_task=0;
$coffee=0;
$stress=0;
$warning=0;
$noodle_task=0;
$noodle_day=0;
$classsleep=0;
$homework=0;
$diligent=0;
$lazy=0;
$diligent_king=0;
$diligent_god=0;
$lazy_king=0;
$lazy_god=0;
$lovers=0;
$lovers_talkleft=0;
$lovers_talkright=0;
$singer=0;
$lastdinner=0;
$domitoryhomework=0;
$week=0;
$hospital=0;
session_start(); 
$_SESSION['word']=0;
$_SESSION['word1']=0;
$_SESSION['life']=$life;
$_SESSION['day']=$day;
$_SESSION['class']=$class;
$_SESSION['chinese'] = $chinese;
$_SESSION['maths'] = $maths;
$_SESSION['english'] = $english;
$_SESSION['physics'] = $physics;
$_SESSION['chemistry'] = $chemistry;
$_SESSION['biology'] = $biology;
$_SESSION['politics'] = $politics;
$_SESSION['history'] = $history;
$_SESSION['geography'] = $geography;
$_SESSION['music'] = $music;
$_SESSION['coffee_task'] = $coffee_task;
$_SESSION['coffee'] = $coffee;
$_SESSION['stress'] = $stress;
$_SESSION['warning'] = $warning;
$_SESSION['noodle_task'] = $noodle_task;
$_SESSION['noodle_day'] = $noodle_day;
$_SESSION['classsleep'] = $classsleep;
$_SESSION['homework'] = $homework;
$_SESSION['diligent'] = $diligent;
$_SESSION['lazy'] = $lazy;
$_SESSION['diligent_king'] = $diligent_king;
$_SESSION['diligent_god'] = $diligent_god;
$_SESSION['lazy_king'] = $lazy_king;
$_SESSION['lazy_god'] = $lazy_god;
$_SESSION['lovers'] = $lovers;
$_SESSION['lovers_talkleft'] = $lovers_talkleft;
$_SESSION['lovers_talkright'] = $lovers_talkright;
$_SESSION['singer'] = $singer;
$_SESSION['lastdinner'] = $lastdinner;
$_SESSION['domitoryhomework'] = $domitoryhomework;
$_SESSION['week']=$week;
$name1=$_SESSION['username'];
$sql = "update mytb set ending_tsinghua=1,hospital=$hospital,life=$life,day=$day,week=$week,class=$class,music=$music,coffee_task=$coffee_task,coffee=$coffee,stress=$stress,warning=$warning,noodle_task=$noodle_task,noodle_day=$noodle_day,classsleep=$classsleep,homework=$homework,diligent=$diligent,lazy=$lazy,diligent_king=$diligent_king,diligent_god=$diligent_god,lazy_king=$lazy_king,lazy_god=$lazy_god,lovers=$lovers,lovers_talkleft=$lovers_talkleft,lovers_talkright=$lovers_talkright,singer=$singer,lastdinner=$lastdinner,domitoryhomework=$domitoryhomework,chinese=$chinese,maths=$maths,english=$english,physics=$physics,chemistry=$chemistry,biology=$biology,politics=$politics,history=$history,geography=$geography where name1='$name1'";
$result = $con->query($sql);

$sql = "update mytb set ending_tsinghua=1 where name1=$name1";
$result = $con->query($sql);
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <title>交闵小游戏3.0</title>
</head>
<body>
<audio id="music" src="music.m4a" hidden="true" loop="loop"  controls autoplay></audio>
<script>
  var musicOn = sessionStorage.getItem('musicOn');
if(musicOn=="0"){ 
  const audios = document.getElementsByTagName('audio');  
    for (let audio of audios) {  
        audio.pause();  
        audio.muted = true;  
    }   
}
  var music = document.getElementById("music");
  var currentTime = 0;

  // 监听音乐播放事件
  music.addEventListener("timeupdate", function() {
    currentTime = music.currentTime;
  });

  // 监听页面离开事件
  window.addEventListener("beforeunload", function() {
    sessionStorage.setItem("currentTime", currentTime);
  });

  // 监听页面加载事件
  window.addEventListener("load", function() {
    var storedTime = sessionStorage.getItem("currentTime");
    if (storedTime) {
      music.currentTime = parseFloat(storedTime);
      music.play();
    }
  });
</script>
<img src="weishen.jpg"  height=70% style="position:absolute;left=30%;top:0%;"/>
<link href="css/jump.css" rel="stylesheet" type="text/css" />
<link href="css/caught.css" rel="stylesheet" type="text/css" />
<div class = "main_box">
    <p style="font-size: 30px; color:#000000;"> 结局：两年半以后，你考上了清华！ </p>
</div> 

<div class = "main_box2">
    <p style="font-size: 30px; color:#000000;"> 现实中也请为此努力吧！ </p>
</div> 

<button type="submit" class='button_continue' onclick="window.location.href='creator2.html'">  </button>
</body>
</html>