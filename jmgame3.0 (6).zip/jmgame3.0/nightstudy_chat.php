<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT class,stress,lovers FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $class = $row['class'];
    $stress = $row['stress'];
    $lovers=$row['lovers'];
}

if($lovers==1){
    echo '<script>window.location.href = "lovers_chat.php";</script>';
}
$class+=1;
$stress-=3;
$_SESSION['word']=10;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;

$sql = "update mytb set class=$class,stress=$stress where name1='$name1'";
$result = $con->query($sql);

echo '<script>window.location.href = "newgame_basic.php";</script>';
?>