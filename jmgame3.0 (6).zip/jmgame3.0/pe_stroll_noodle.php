<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT week,noodle_task FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $week = $row['week'];
    $noodle_task = $row['noodle_task'];
}

if($week>=2 and $noodle_task==0){
    echo '<script>window.location.href = "noodle_task.php";</script>';
}
else{
    echo '<script>window.location.href = "read_auto.php";</script>';
}

?>