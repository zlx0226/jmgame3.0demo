<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life,class,stress,homework FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $class = $row['class'];
    $stress = $row['stress'];
    $homework = $row['homework'];
    $life=$row['life'];
}

$possibility=rand(1,5);
if($possibility<=3){
    $homework+=rand(10,30);
    if($homework<=100){
        $_SESSION['word']=4;
    }
    else{
        $_SESSION['homework']=$homework;
        $_SESSION['word']=4;
        echo '<script>window.location.href = "homework_skip.php";</script>';
    }
}
else{
    $stress+=5;
    $_SESSION['word']=5;
}
$life-=3;
$class+=1;
$_SESSION['life']=$life;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;
$_SESSION['homework'] = $homework;

$sql = "update mytb set life=$life,class=$class,stress=$stress,homework=$homework where name1='$name1'";
$result = $con->query($sql);

echo '<script>window.location.href = "newgame_basic.php";</script>';
?>