<?php
echo '<script>window.location.href = "read_auto.php";</script>';
?>