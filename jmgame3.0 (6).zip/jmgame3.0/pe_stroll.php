<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT class,stress FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $class = $row['class'];
    $stress = $row['stress'];
}

    $stress-=3;
    $_SESSION['word']=9;

    $class+=1;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;

$sql = "update mytb set class=$class,stress=$stress where name1='$name1'";
$result = $con->query($sql);

$possibility=rand(1,10);
if($possibility>=6){
    echo '<script>window.location.href = "pe_stroll_cat.php";</script>';
}
elseif($possibility==1){
    echo '<script>window.location.href = "pe_stroll_garbage.php";</script>';
}
else{
    echo '<script>window.location.href = "pe_stroll_normal.php";</script>';
}

?>