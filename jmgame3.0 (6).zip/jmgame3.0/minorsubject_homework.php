<?php
require 'database_connect.php';

session_start();
$name1=$_SESSION['username'];
$sql = "SELECT life,class,stress,homework FROM mytb WHERE name1='$name1'";
$result = $con->query($sql);
if (!$result) {
    // 打印错误信息
    echo "Error: " . $con->error;}
while($row = $result->fetch_assoc()) {
    $class = $row['class'];
    $stress = $row['stress'];
    $homework = $row['homework'];
    $life=$row['life'];
}

$homework+=rand(10,30);
if($homework<=100){
    $_SESSION['word']=4;
}
else{
    $_SESSION['homework']=$homework;
    $_SESSION['word']=4;
    echo '<script>window.location.href = "homework_skip.php";</script>';
}

$class+=1;
$life-=3;
$_SESSION['life']=$life;
$_SESSION['class']=$class;
$_SESSION['stress'] = $stress;
$_SESSION['homework'] = $homework;

$sql = "update mytb set life=$life,class=$class,stress=$stress,homework=$homework where name1='$name1'";
$result = $con->query($sql);

echo '<script>window.location.href = "newgame_basic.php";</script>';
?>